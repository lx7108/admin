#!/bin/bash

# 域名配置脚本
DOMAIN="h-pulse.com.cn"
EMAIL="your-email@example.com"  # 您的邮箱，用于SSL证书

echo "🌐 开始配置域名 $DOMAIN..."

# 确认域名已解析
echo "⚠️ 请确保已将域名 $DOMAIN 和 www.$DOMAIN 解析到服务器IP: $(curl -s ifconfig.me)"
read -p "域名是否已解析？(y/n): " domain_resolved
if [[ "$domain_resolved" != "y" && "$domain_resolved" != "Y" ]]; then
    echo "❌ 请先解析域名，然后再运行此脚本"
    exit 1
fi

# 使用正确的配置文件
echo "📄 更新Nginx配置..."
cp nginx-ssl.conf nginx.conf

# 重启服务
echo "🔄 重启服务以应用新配置..."
docker compose down
docker compose up -d

# 设置SSL证书 (使用Certbot)
echo "🔒 是否设置SSL证书？"
read -p "安装SSL证书？(y/n): " install_ssl
if [[ "$install_ssl" == "y" || "$install_ssl" == "Y" ]]; then
    # 安装Certbot
    echo "📦 安装Certbot..."
    if command -v apt-get &> /dev/null; then
        apt-get update
        apt-get install -y certbot python3-certbot-nginx
    elif command -v yum &> /dev/null; then
        yum install -y certbot python3-certbot-nginx
    else
        echo "❌ 无法安装Certbot，请手动安装"
        exit 1
    fi
    
    # 停止前端容器以释放80端口
    docker stop $(docker ps -q -f name=frontend)
    
    # 获取证书
    echo "🔑 获取SSL证书..."
    certbot certonly --standalone -d $DOMAIN -d www.$DOMAIN --email $EMAIL --agree-tos --non-interactive
    
    # 证书获取成功后，更新Nginx配置
    if [ -d "/etc/letsencrypt/live/$DOMAIN" ]; then
        echo "✅ 证书获取成功，更新Nginx配置..."
        
        # 创建SSL版本的配置文件
        cat > nginx-ssl.conf << EOF
server {
    listen 80;
    server_name h-pulse.com.cn www.h-pulse.com.cn;
    
    # 重定向HTTP到HTTPS
    return 301 https://\$host\$request_uri;
}

server {
    listen 443 ssl;
    server_name h-pulse.com.cn www.h-pulse.com.cn;
    
    ssl_certificate /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;
    
    location / {
        root /app/dist;
        index index.html;
        try_files \$uri \$uri/ /index.html;
    }
    
    location /api/ {
        proxy_pass http://backend:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF
        
        # 更新docker-compose.yml，添加443端口
        if ! grep -q "443:443" docker-compose.yml; then
            sed -i 's/- "80:80"/- "80:80"\n      - "443:443"/g' docker-compose.yml
        fi
        
        # 更新volumes，挂载证书
        if ! grep -q "letsencrypt" docker-compose.yml; then
            sed -i '/frontend:/,/networks:/ s/networks:/volumes:\n      - /etc/letsencrypt:/etc/letsencrypt:ro\n    networks:/g' docker-compose.yml
        fi
        
        # 更新配置并重启服务
        cp nginx-ssl.conf nginx.conf
        
        # 启动服务
        docker compose up -d
        
        echo "✅ SSL配置完成！"
        echo "🔒 网站现在可通过HTTPS访问: https://$DOMAIN"
    else
        echo "❌ 证书获取失败，请检查域名解析并手动获取证书"
        # 重新启动服务
        docker compose up -d
    fi
fi

echo "✅ 域名配置完成！"
echo "🌐 网站现在可通过域名访问: http://$DOMAIN"
if [[ "$install_ssl" == "y" || "$install_ssl" == "Y" ]]; then
    echo "🔒 并且可以通过HTTPS访问: https://$DOMAIN"
fi 