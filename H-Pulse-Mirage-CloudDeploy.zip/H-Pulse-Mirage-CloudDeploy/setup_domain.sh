#!/bin/bash

# 帮助信息
show_help() {
    echo "使用方法: $0 [选项]"
    echo "选项:"
    echo "  -d, --domain DOMAIN   设置域名"
    echo "  -e, --email EMAIL     设置电子邮箱 (用于SSL证书)"
    echo "  -s, --ssl             配置SSL证书"
    echo "  -h, --help            显示帮助信息"
    exit 0
}

# 默认配置
DOMAIN=""
EMAIL=""
SETUP_SSL=false

# 解析命令行参数
while [[ $# -gt 0 ]]; do
    case $1 in
        -d|--domain)
            DOMAIN="$2"
            shift 2
            ;;
        -e|--email)
            EMAIL="$2"
            shift 2
            ;;
        -s|--ssl)
            SETUP_SSL=true
            shift
            ;;
        -h|--help)
            show_help
            ;;
        *)
            echo "未知选项: $1"
            show_help
            ;;
    esac
done

# 检查域名参数
if [[ -z "$DOMAIN" ]]; then
    echo "错误: 缺少域名参数"
    show_help
fi

echo "🌐 配置域名: $DOMAIN..."

# 确保安装了DNS工具
if ! command -v dig &> /dev/null; then
    echo "📦 安装DNS工具..."
    apt-get update && apt-get install -y dnsutils
fi

# 检查域名是否已解析到本服务器
SERVER_IP=$(curl -s ifconfig.me)
DOMAIN_IP=$(dig +short $DOMAIN)

if [[ -z "$DOMAIN_IP" ]]; then
    echo "⚠️ 警告: 域名 $DOMAIN 未能解析到IP地址"
    echo "请确保已正确配置DNS解析，将域名解析到服务器IP: $SERVER_IP"
    read -p "是否继续配置? (y/n): " continue_setup
    if [[ "$continue_setup" != "y" && "$continue_setup" != "Y" ]]; then
        echo "配置已取消"
        exit 1
    fi
elif [[ "$DOMAIN_IP" != "$SERVER_IP" ]]; then
    echo "⚠️ 警告: 域名 $DOMAIN 当前解析到 $DOMAIN_IP，而非服务器IP $SERVER_IP"
    echo "请确保已正确配置DNS解析，将域名解析到服务器IP: $SERVER_IP"
    read -p "是否继续配置? (y/n): " continue_setup
    if [[ "$continue_setup" != "y" && "$continue_setup" != "Y" ]]; then
        echo "配置已取消"
        exit 1
    fi
else
    echo "✅ 域名 $DOMAIN 已正确解析到服务器IP: $SERVER_IP"
fi

# 将域名保存到配置文件
echo "DOMAIN_NAME=$DOMAIN" > .env

# 如果需要配置SSL
if [[ "$SETUP_SSL" == true ]]; then
    echo "🔒 配置SSL证书..."
    
    # 如果未提供邮箱，请求输入
    if [[ -z "$EMAIL" ]]; then
        read -p "请输入您的电子邮箱 (用于SSL证书): " EMAIL
    fi
    
    # 安装certbot
    if ! command -v certbot &> /dev/null; then
        echo "📦 安装 certbot..."
        apt-get update
        apt-get install -y certbot
    fi
    
    # 创建SSL证书目录
    mkdir -p ssl
    
    # 停止可能占用80端口的服务
    echo "⏳ 临时停止前端服务以获取证书..."
    docker stop $(docker ps -q -f name=frontend) || true
    
    # 获取证书
    echo "🔑 获取SSL证书..."
    certbot certonly --standalone --preferred-challenges http \
        -d $DOMAIN \
        --email $EMAIL \
        --agree-tos --no-eff-email \
        --keep-until-expiring
    
    # 复制证书到ssl目录
    echo "📋 复制证书..."
    cp /etc/letsencrypt/live/$DOMAIN/fullchain.pem ssl/cert.pem
    cp /etc/letsencrypt/live/$DOMAIN/privkey.pem ssl/key.pem
    
    # 设置权限
    chmod 644 ssl/cert.pem
    chmod 644 ssl/key.pem
    
    echo "✅ SSL证书配置完成"
    
    # 设置证书自动更新（使用绝对路径）
    echo "📅 配置证书自动更新..."
    CURRENT_DIR=$(pwd)
    (crontab -l 2>/dev/null; echo "0 3 * * * certbot renew --quiet && cp /etc/letsencrypt/live/$DOMAIN/fullchain.pem $CURRENT_DIR/ssl/cert.pem && cp /etc/letsencrypt/live/$DOMAIN/privkey.pem $CURRENT_DIR/ssl/key.pem") | crontab -
    
    echo "SSL_CERT_PATH=./ssl" >> .env
fi

echo "✅ 域名配置完成"
if [[ "$SETUP_SSL" == true ]]; then
    echo "🌐 您的网站将通过 https://$DOMAIN 访问"
else
    echo "🌐 您的网站将通过 http://$DOMAIN 访问"
fi 