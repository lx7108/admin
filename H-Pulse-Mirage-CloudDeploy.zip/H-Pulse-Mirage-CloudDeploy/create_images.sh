#!/bin/bash

# 创建目录（如果不存在）
mkdir -p mirage-vue-console/public/images

# 生成占位头像
echo "生成占位头像..."
cat > mirage-vue-console/public/placeholder-avatar.svg << EOF
<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">
  <rect width="200" height="200" fill="#f0f0f0"/>
  <circle cx="100" cy="80" r="40" fill="#d0d0d0"/>
  <circle cx="100" cy="200" r="80" fill="#d0d0d0"/>
  <text x="100" y="190" font-family="Arial" font-size="14" text-anchor="middle" fill="#888">头像占位图</text>
</svg>
EOF

# 生成网站图标
echo "生成网站图标..."
cat > mirage-vue-console/public/favicon.svg << EOF
<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
  <circle cx="16" cy="16" r="15" fill="#42b983" stroke="#2c3e50" stroke-width="2"/>
  <text x="16" y="22" font-family="Arial" font-size="18" font-weight="bold" text-anchor="middle" fill="white">M</text>
</svg>
EOF

# 生成网站Logo
echo "生成网站Logo..."
cat > mirage-vue-console/public/logo.svg << EOF
<svg xmlns="http://www.w3.org/2000/svg" width="200" height="60" viewBox="0 0 200 60">
  <rect width="200" height="60" fill="none"/>
  <text x="10" y="35" font-family="Arial" font-size="24" font-weight="bold" fill="#42b983">H-Pulse·Mirage</text>
  <text x="10" y="50" font-family="Arial" font-size="12" fill="#2c3e50">命运模拟与演出引擎</text>
</svg>
EOF

# 生成场景背景图片
echo "生成场景背景图片..."
mkdir -p mirage-vue-console/public/images/scenes

# 咖啡馆场景
cat > mirage-vue-console/public/images/scenes/cafe.svg << EOF
<svg xmlns="http://www.w3.org/2000/svg" width="600" height="300" viewBox="0 0 600 300">
  <rect width="600" height="300" fill="#f5f5f5"/>
  <rect x="50" y="50" width="500" height="200" fill="#e0e0e0" rx="10" ry="10"/>
  <text x="300" y="160" font-family="Arial" font-size="24" text-anchor="middle" fill="#888">城市咖啡馆</text>
</svg>
EOF

# 图书馆场景
cat > mirage-vue-console/public/images/scenes/library.svg << EOF
<svg xmlns="http://www.w3.org/2000/svg" width="600" height="300" viewBox="0 0 600 300">
  <rect width="600" height="300" fill="#f0eae0"/>
  <rect x="50" y="50" width="500" height="200" fill="#d0c8b0" rx="10" ry="10"/>
  <text x="300" y="160" font-family="Arial" font-size="24" text-anchor="middle" fill="#888">古老图书馆</text>
</svg>
EOF

# 山顶场景
cat > mirage-vue-console/public/images/scenes/mountain.svg << EOF
<svg xmlns="http://www.w3.org/2000/svg" width="600" height="300" viewBox="0 0 600 300">
  <rect width="600" height="300" fill="#a4c2f4"/>
  <polygon points="0,300 150,100 300,250 450,50 600,300" fill="#8fbc8f"/>
  <circle cx="550" cy="80" r="40" fill="#f9d71c"/>
  <text x="300" y="160" font-family="Arial" font-size="24" text-anchor="middle" fill="#fff">山顶日落</text>
</svg>
EOF

# 海边场景
cat > mirage-vue-console/public/images/scenes/beach.svg << EOF
<svg xmlns="http://www.w3.org/2000/svg" width="600" height="300" viewBox="0 0 600 300">
  <rect width="600" height="150" fill="#87ceeb"/>
  <rect width="600" height="150" y="150" fill="#f0e68c"/>
  <rect x="400" y="100" width="100" height="80" fill="#8b4513"/>
  <text x="300" y="160" font-family="Arial" font-size="24" text-anchor="middle" fill="#fff">海边小屋</text>
</svg>
EOF

echo "所有图片生成完成！" 