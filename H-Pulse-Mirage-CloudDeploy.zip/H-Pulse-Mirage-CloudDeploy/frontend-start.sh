#!/bin/sh
set -e

echo "等待后端服务就绪..."
COUNT=0
MAX_RETRIES=30

# 检查 backend 服务是否可用
while ! ping -c 1 -W 1 backend > /dev/null 2>&1; do
  if [ $COUNT -eq $MAX_RETRIES ]; then
    echo "警告: 无法连接到后端服务，但仍会继续启动..."
    break
  fi
  COUNT=$((COUNT+1))
  echo "等待后端服务... $COUNT/$MAX_RETRIES"
  sleep 2
done

echo "验证 Nginx 配置..."
nginx -t || {
  echo "Nginx 配置验证失败，使用简化配置..."
  # 如果 nginx 配置验证失败，创建一个简单的不依赖后端的配置
  cat > /etc/nginx/conf.d/default.conf << EOF
server {
    listen 80;
    server_name _;
    
    location / {
        root /usr/share/nginx/html;
        index index.html;
        try_files \$uri \$uri/ /index.html;
    }
}
EOF
  nginx -t
}

echo "启动 Nginx 服务..."
exec nginx -g "daemon off;" 