from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.pool import QueuePool
from sqlalchemy.exc import SQLAlchemyError
from contextlib import contextmanager
import logging
import time
from app.config import settings

# 配置日志
logger = logging.getLogger(__name__)

# 数据库引擎配置
engine = create_engine(
    settings.DATABASE_URL,
    poolclass=QueuePool,
    pool_size=5,  # 减小连接池大小
    max_overflow=10,
    pool_timeout=60,  # 增加连接超时时间到60秒
    pool_recycle=1800,  # 30分钟回收连接
    pool_pre_ping=True,  # 每次连接前ping，确保连接有效
    echo=settings.DEBUG,  # 在DEBUG模式下打印SQL语句
    connect_args={
        "connect_timeout": 60,  # PostgreSQL连接超时时间
        "application_name": "h_pulse_mirage",  # 应用名称
        "keepalives": 1,  # 启用TCP keepalive
        "keepalives_idle": 60,  # 空闲60秒后发送keepalive
        "keepalives_interval": 10,  # keepalive间隔10秒
        "keepalives_count": 5  # 5次重试
    }
)

# 数据库连接事件监听
@event.listens_for(engine, "connect")
def connect(dbapi_connection, connection_record):
    logger.info("Database connection established")

@event.listens_for(engine, "checkout")
def checkout(dbapi_connection, connection_record, connection_proxy):
    logger.debug("Database connection checked out")

@event.listens_for(engine, "close")
def close_connection(dbapi_connection, connection_record):
    logger.info("Database connection closed")

# Session工厂
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# 基础模型类
class CustomBase:
    @declared_attr
    def __tablename__(cls):
        # 自动生成小写表名
        return cls.__name__.lower()

Base = declarative_base(cls=CustomBase)

# FastAPI依赖项函数
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# 上下文管理器，用于非依赖项的数据库会话需求
@contextmanager
def get_db_session():
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except SQLAlchemyError as e:
        session.rollback()
        logger.error(f"Database error: {str(e)}")
        raise
    finally:
        session.close()

# 测试数据库连接
def test_connection():
    max_retries = 5
    retry_delay = 5  # 秒
    
    for attempt in range(max_retries):
        try:
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))
                conn.commit()
            logger.info("Database connection test successful")
            return True
        except SQLAlchemyError as e:
            logger.error(f"Database connection test failed (attempt {attempt + 1}/{max_retries}): {str(e)}")
            if attempt < max_retries - 1:
                time.sleep(retry_delay)
            else:
                return False

# 初始化数据库表
def init_db():
    """初始化数据库"""
    try:
        Base.metadata.create_all(bind=engine)
        logger.info("Database tables created successfully")
    except SQLAlchemyError as e:
        logger.error(f"Failed to create database tables: {str(e)}")
        raise 