#!/bin/bash

# 部署配置
SERVER_IP="8.148.68.190"
SERVER_USER="root"
DEPLOY_DIR="H-Pulse-Mirage-CloudDeploy"
LOCAL_ZIP="$DEPLOY_DIR.zip"

echo "🚀 开始一键部署 H-Pulse·Mirage 到云服务器 $SERVER_IP..."

# 创建部署目录
echo "📂 创建临时部署目录..."
mkdir -p $DEPLOY_DIR

# 复制必要文件
echo "📋 复制项目文件..."
cp -r mirage-vue-console $DEPLOY_DIR/
cp -r mirage-backend-full $DEPLOY_DIR/
cp docker-compose.yml $DEPLOY_DIR/
cp Dockerfile.frontend $DEPLOY_DIR/
cp Dockerfile.backend $DEPLOY_DIR/
cp init_postgres.sql $DEPLOY_DIR/
cp init_server.sh $DEPLOY_DIR/
cp nginx.conf $DEPLOY_DIR/

# 复制Docker镜像加速器脚本
cp setup_docker_mirror.sh $DEPLOY_DIR/

# 打包文件
echo "📦 打包项目文件..."
rm -f $LOCAL_ZIP
zip -r $LOCAL_ZIP $DEPLOY_DIR

# 询问用户是否有SSH密钥
read -p "您是否已经设置SSH密钥认证？(y/n): " has_key

if [[ "$has_key" == "y" || "$has_key" == "Y" ]]; then
    # 使用SSH自动上传和执行
    echo "📤 上传文件到服务器..."
    
    # 上传文件
    scp $LOCAL_ZIP $SERVER_USER@$SERVER_IP:~/$LOCAL_ZIP
    
    # 执行远程命令
    ssh $SERVER_USER@$SERVER_IP "unzip -o ~/$LOCAL_ZIP -d ~/ && cd ~/$DEPLOY_DIR && bash setup_docker_mirror.sh && bash init_server.sh"
else
    # 提供手动操作指南
    echo "⚠️ 请手动完成以下步骤:"
    echo "   1. 手动上传 $LOCAL_ZIP 到服务器"
    echo "   2. 登录服务器: ssh $SERVER_USER@$SERVER_IP"
    echo "   3. 解压文件: unzip -o ~/$LOCAL_ZIP -d ~/"
    echo "   4. 进入目录: cd ~/$DEPLOY_DIR"
    echo "   5. 配置Docker: bash setup_docker_mirror.sh" 
    echo "   6. 执行部署: bash init_server.sh"
fi

# 清理本地文件
read -p "是否清理本地临时文件？(y/n): " clean_up

if [[ "$clean_up" == "y" || "$clean_up" == "Y" ]]; then
    echo "🧹 清理本地临时文件..."
    rm -rf $DEPLOY_DIR
    # 保留zip文件，以便需要时可以再次使用
fi

echo "✅ 部署流程执行完毕！"
echo "🌐 前端访问地址: http://$SERVER_IP:80"
echo "🌐 后端API地址: http://$SERVER_IP:8000/api" 