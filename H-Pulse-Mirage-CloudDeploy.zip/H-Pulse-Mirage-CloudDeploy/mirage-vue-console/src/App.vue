<template>
  <div class="app-container">
    <header>
      <div class="logo">
        <img src="/logo.svg" alt="H-Pulse·Mirage Logo" class="logo-image">
      </div>
      <nav>
        <router-link to="/">首页</router-link>
        <router-link v-if="isLoggedIn" to="/simulation">命运模拟</router-link>
        <router-link v-if="isLoggedIn" to="/theater">命运剧场</router-link>
        <router-link v-if="isLoggedIn" to="/character">角色管理</router-link>
        <router-link v-if="isLoggedIn" to="/user" class="user-link">
          <span class="user-icon">👤</span> {{ username || '个人中心' }}
        </router-link>
        <router-link v-else to="/user">登录/注册</router-link>
      </nav>
    </header>
    
    <main>
      <router-view />
    </main>
    
    <footer>
      <p>H-Pulse·Mirage © 2023</p>
    </footer>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import { useRoute } from 'vue-router'
import { authService } from './services/auth'

const route = useRoute()
const isLoggedIn = ref(false)
const username = ref('')

// 检查登录状态
const checkAuth = async () => {
  isLoggedIn.value = authService.isLoggedIn()
  
  if (isLoggedIn.value) {
    try {
      const user = await authService.getCurrentUser()
      username.value = user?.username || ''
    } catch (error) {
      console.error('获取用户信息失败:', error)
      username.value = ''
    }
  } else {
    username.value = ''
  }
}

// 页面加载时和路由变化时检查登录状态
onMounted(checkAuth)
watch(() => route.path, checkAuth)
</script>

<style>
.app-container {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 20px;
}

header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 0;
  border-bottom: 1px solid #eee;
}

.logo {
  display: flex;
  align-items: center;
}

.logo-image {
  height: 40px;
  width: auto;
}

nav {
  display: flex;
  gap: 20px;
}

nav a {
  text-decoration: none;
  color: #2c3e50;
  font-weight: bold;
}

nav a.router-link-active {
  color: #42b983;
}

.user-link {
  display: flex;
  align-items: center;
}

.user-icon {
  margin-right: 5px;
}

main {
  min-height: 70vh;
  padding: 20px 0;
}

footer {
  text-align: center;
  padding: 20px 0;
  border-top: 1px solid #eee;
  color: #666;
}

:root {
  --color-primary: #42b983;
  --color-secondary: #2c3e50;
}
</style> 