import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import { authService } from '../services/auth'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/simulation',
      name: 'simulation',
      component: () => import('../views/SimulationView.vue'),
      meta: { requiresAuth: true }
    },
    {
      path: '/theater',
      name: 'theater',
      component: () => import('../views/TheaterView.vue'),
      meta: { requiresAuth: true }
    },
    {
      path: '/character',
      name: 'character',
      component: () => import('../views/CharacterView.vue'),
      meta: { requiresAuth: true }
    },
    {
      path: '/user',
      name: 'user',
      component: () => import('../views/UserView.vue')
    }
  ]
})

// 全局前置路由守卫 - 处理需要认证的路由
router.beforeEach((to, from, next) => {
  // 检查路由是否需要认证
  if (to.matched.some(record => record.meta.requiresAuth)) {
    // 如果需要认证，检查是否已登录
    if (!authService.isLoggedIn()) {
      // 未登录，重定向到用户页面
      next({ name: 'user' })
    } else {
      // 已登录，允许访问
      next()
    }
  } else {
    // 不需要认证的路由，直接访问
    next()
  }
})

export default router 