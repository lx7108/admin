<template>
  <div class="simulation">
    <h1>命运模拟</h1>
    
    <div class="simulation-container">
      <div class="simulation-controls">
        <h2>命运模拟控制面板</h2>
        
        <!-- 角色选择 -->
        <div class="form-group">
          <label for="character-select">选择角色:</label>
          <select id="character-select" v-model="selectedCharacter" :disabled="isSimulating">
            <option value="">-- 请选择一个角色 --</option>
            <option v-for="char in characters" :key="char.id" :value="char.id">
              {{ char.name }} (ID: {{ char.id }})
            </option>
          </select>
        </div>
        
        <!-- 模拟步数 -->
        <div class="form-group">
          <label for="simulation-steps">模拟步数:</label>
          <input type="number" id="simulation-steps" v-model="simulationSteps" min="10" max="1000" :disabled="isSimulating">
        </div>
        
        <!-- 操作按钮 -->
        <div class="actions">
          <button @click="startSimulation" :disabled="isSimulating || !selectedCharacter">
            {{ isSimulating ? '模拟中...' : '开始模拟' }}
          </button>
          <button @click="resetSimulation" :disabled="isSimulating || simulationResults.length === 0">
            重置
          </button>
        </div>
        
        <!-- 状态消息 -->
        <div class="status-message" v-if="simulationMessage">
          {{ simulationMessage }}
        </div>
        
        <!-- 错误消息 -->
        <div class="error-message" v-if="simulationError">
          <strong>错误:</strong> {{ simulationError }}
        </div>
        
        <!-- 进度条 -->
        <div class="progress-bar" v-if="simulationProgress > 0">
          <div class="progress-fill" :style="{ width: `${simulationProgress}%` }"></div>
          <span class="progress-text">{{ Math.round(simulationProgress) }}%</span>
        </div>
      </div>
      
      <div class="simulation-results">
        <div v-if="!simulationResults.length && !isSimulating" class="empty-state">
          <p>选择角色并开始模拟以查看结果</p>
        </div>
        
        <div v-if="isSimulating" class="loading">
          <p>命运模拟中，请稍候...</p>
          <div class="progress-bar">
            <div class="progress" :style="{ width: simulationProgress + '%' }"></div>
          </div>
          <p class="progress-text">{{ simulationProgress }}%</p>
        </div>
        
        <div v-if="simulationResults.length && !isSimulating" class="results-list">
          <h3>模拟结果</h3>
          
          <!-- 显示模拟数据是否为后备数据 -->
          <div v-if="usingMockData" class="mock-data-notice">
            注意: 由于无法从服务器获取真实数据，当前显示的是本地生成的模拟数据。
          </div>
          
          <div class="timeline">
            <div v-for="(event, index) in simulationResults" :key="index" class="timeline-event">
              <div class="event-time">第 {{ event.step || (index + 1) }} 步</div>
              <div class="event-content">
                <h4>{{ event.title || event.action || '事件' }}</h4>
                <p>{{ event.description || event.outcome || '无详细信息' }}</p>
                <div v-if="hasEventDetails(event)" class="stats">
                  <template v-if="event.stats">
                    <span v-for="(value, key) in event.stats" :key="key" class="stat-item">
                      {{ key }}: {{ formatValue(value) }}
                    </span>
                  </template>
                  <template v-if="event.reward && !event.stats">
                    <span class="stat-item reward-item">奖励: {{ formatValue(event.reward) }}</span>
                  </template>
                  <template v-if="event.state && !event.stats">
                    <span v-for="(value, key) in event.state" :key="key" class="stat-item">
                      {{ key }}: {{ formatValue(value) }}
                    </span>
                  </template>
                </div>
              </div>
            </div>
          </div>
          
          <div class="debug-info">
            <button @click="showDebug = !showDebug" class="btn secondary">
              {{ showDebug ? '隐藏调试信息' : '显示调试信息' }}
            </button>
            <pre v-if="showDebug">{{ JSON.stringify(simulationResults, null, 2) }}</pre>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { apiService } from '@/services/api'
import axios from 'axios'

const characters = ref([])
const selectedCharacter = ref('')
const simulationSteps = ref(100)
const seed = ref('')
const isSimulating = ref(false)
const simulationProgress = ref(0)
const simulationResults = ref([])
const showDebug = ref(false)
const simulationMessage = ref('')
const simulationError = ref(null)
const usingMockData = ref(false)

// 获取角色列表
onMounted(async () => {
  try {
    simulationMessage.value = '正在从远程服务器获取角色列表...'
    
    // 首先尝试使用apiService的标准方法
    try {
      const data = await apiService.getCharacters()
      if (data && (Array.isArray(data) || Array.isArray(data.data))) {
        const characterData = Array.isArray(data) ? data : data.data
        console.log('成功使用标准API获取角色列表:', characterData)
        
        // 标准化角色数据格式
        characters.value = characterData.map(char => ({
          id: char.id || char.character_id,
          name: char.name || char.character_name || `角色 ${char.id || '未知'}`
        }))
        
        simulationMessage.value = `成功加载 ${characterData.length} 个角色`
        return
      }
    } catch (e) {
      console.log('标准API获取角色失败，尝试备选方法:', e.message)
    }
    
    // 如果标准方法失败，尝试多个可能的API端点
    let characterData = null
    const possibleEndpoints = [
      '/character/list',
      '/character/all',
      '/characters'
    ]
    
    // 尝试每个端点
    for (const endpoint of possibleEndpoints) {
      try {
        console.log(`尝试从 ${endpoint} 获取角色列表`)
        
        // 使用axios直接请求
        const baseURL = import.meta.env.VITE_API_BASE_URL || 'http://47.76.194.238:8080/api'
        const response = await axios.get(`${baseURL.replace(/\/+$/, '')}${endpoint}`)
        
        // 提取角色数据
        if (Array.isArray(response.data)) {
          characterData = response.data
          break
        } else if (response.data?.characters) {
          characterData = response.data.characters
          break
        } else if (response.data?.data && Array.isArray(response.data.data)) {
          characterData = response.data.data
          break
        } else if (response.data?.result) {
          characterData = response.data.result
          break
        } else if (Array.isArray(response)) {
          // 有时response直接就是数据，跳过data属性
          characterData = response
          break
        }
      } catch (e) {
        console.log(`从 ${endpoint} 获取角色列表失败:`, e.message)
      }
    }
    
    if (characterData && characterData.length > 0) {
      console.log('成功获取角色列表:', characterData)
      // 标准化角色数据格式
      characters.value = characterData.map(char => ({
        id: char.id || char.character_id,
        name: char.name || char.character_name || `角色 ${char.id || '未知'}`
      }))
      simulationMessage.value = `成功加载 ${characterData.length} 个角色`
    } else {
      throw new Error('未从任何端点获取到角色数据')
    }
  } catch (error) {
    console.error('获取角色列表失败:', error)
    simulationMessage.value = '无法从服务器获取角色，使用默认数据'
    // 使用模拟数据作为后备方案
    characters.value = [
      { id: 1, name: '张三' },
      { id: 2, name: '李四' },
      { id: 3, name: '王五' }
    ]
  }
})

// 开始模拟
const startSimulation = async () => {
  if (!selectedCharacter.value) {
    console.warn('未选择角色，无法运行模拟')
    simulationMessage.value = '请先选择一个角色'
    return
  }

  if (isSimulating.value) {
    console.warn('模拟已在运行中')
    return
  }

  try {
    console.log('开始运行命运模拟', selectedCharacter.value, simulationSteps.value)
    isSimulating.value = true
    simulationProgress.value = 5
    simulationMessage.value = '准备角色数据...'
    simulationResults.value = []
    simulationError.value = null
    showDebug.value = false
    
    let progressUpdater = null;
    
    try {
      // 创建一个进度更新器
      progressUpdater = setInterval(() => {
        if (simulationProgress.value < 95) {
          simulationProgress.value += Math.floor(Math.random() * 10) + 1
          if (simulationProgress.value > 95) simulationProgress.value = 95
        }
      }, 800)

      // 准备API调用参数
      const data = {
        character_id: selectedCharacter.value,
        steps: simulationSteps.value
      }
      
      simulationMessage.value = '正在进行命运计算...'
      
      // 运行模拟
      const response = await apiService.runSimulation(data)
      
      // 清除进度更新器
      clearInterval(progressUpdater)
      simulationProgress.value = 100
      simulationMessage.value = '模拟完成！解析结果...'
      
      // 尝试多种可能的结果格式
      let results = null
      console.log('收到模拟结果:', response)
      
      try {
        // 标准格式
        if (response.data?.results) {
          results = response.data.results
        } 
        // 事件数组格式
        else if (Array.isArray(response.data)) {
          results = response.data
        }
        // 包含events的格式
        else if (response.data?.events) {
          results = response.data.events
        }
        // 包含history的格式
        else if (response.data?.history) {
          results = response.data.history
        }
        // 包含timeline的格式
        else if (response.data?.timeline) {
          results = response.data.timeline
        }
        // 包含steps的格式
        else if (response.data?.steps) {
          results = response.data.steps
        }
        // 远程公网API特定格式
        else if (response.data?.simulationResult) {
          results = response.data.simulationResult
        }
        else if (response.data?.result?.events) {
          results = response.data.result.events
        }
        else if (response.data?.result?.timeline) {
          results = response.data.result.timeline
        }
        // data字段就是字符串，可能是响应体格式有误
        else if (typeof response.data === 'string') {
          try {
            // 尝试解析为JSON
            if (response.data.trim().startsWith('{') || response.data.trim().startsWith('[')) {
              const parsedData = JSON.parse(response.data)
              
              // 检查已解析的数据中的各种可能结构
              if (parsedData.events) results = parsedData.events
              else if (parsedData.results) results = parsedData.results
              else if (parsedData.timeline) results = parsedData.timeline
              else if (parsedData.history) results = parsedData.history
              else if (parsedData.data?.events) results = parsedData.data.events
              else if (parsedData.data?.results) results = parsedData.data.results
              else if (Array.isArray(parsedData)) results = parsedData
              else if (typeof parsedData === 'object') results = [parsedData]
            } 
            // 或者在适当的地方拆分字符串，获取事件描述
            else if (response.data.includes('\n')) {
              results = response.data.split('\n').filter(line => line.trim()).map((line, i) => ({
                step: i + 1,
                title: `事件 ${i + 1}`,
                description: line.trim()
              }))
            } else {
              // 整个字符串作为一个事件
              results = [{
                step: 1,
                title: '模拟结果',
                description: response.data
              }]
            }
          } catch (e) {
            console.error('解析字符串结果失败:', e, response.data)
          }
        }
        // 直接就是结果对象(不在data中)
        else if (Array.isArray(response.results)) {
          results = response.results
        }
        else if (response.events) {
          results = response.events
        }
        // 数据可能在response本身，而不是response.data
        else if (Array.isArray(response)) {
          results = response
        }
        // response本身是对象，尝试直接使用
        else if (typeof response === 'object' && !response.data) {
          // 检查对象上常见的结果字段
          if (response.events) results = response.events
          else if (response.results) results = response.results
          else if (response.timeline) results = response.timeline
          else results = [response]
        }
        // 尝试将整个response作为结果
        else if (typeof response === 'object') {
          results = [response]
        }
        
        if (!results || results.length === 0) {
          console.warn('无法理解的响应格式:', response)
          throw new Error('未能识别的结果格式或结果为空')
        }
        
        // 标准化结果格式
        results = results.map((event, index) => {
          // 处理事件内容为字符串的情况
          if (typeof event === 'string') {
            return {
              step: index + 1,
              title: `事件 ${index + 1}`,
              description: event,
              stats: null
            }
          }
          
          return {
            step: event.step || event.id || event.eventId || index + 1,
            title: event.title || event.name || event.eventName || event.action || event.type || '事件',
            description: event.description || event.outcome || event.content || event.text || event.msg || '无详细信息',
            stats: event.stats || event.attributes || event.properties || event.state?.attributes || null,
            reward: event.reward || event.rewards || null,
            state: event.state || null
          }
        })
        
        simulationResults.value = results
        simulationMessage.value = '命运线模拟完成'
        usingMockData.value = false
      } catch (parseError) {
        console.warn('解析模拟结果失败:', parseError, response)
        simulationMessage.value = '解析结果时出现问题，显示模拟数据'
        
        // 生成模拟数据用于演示
        simulationResults.value = generateMockResults('parse_error')
      }
    } catch (error) {
      // 清除进度更新
      clearInterval(progressUpdater)
      
      // 记录错误信息
      console.error('模拟执行错误:', error)
      simulationError.value = error.message || '运行模拟时出错'
      
      // 显示友好的错误消息
      const errorMessage = 
        error.response?.status === 404 ? '找不到模拟API端点' :
        error.response?.status === 401 ? '未授权访问模拟API' :
        error.response?.status === 500 ? '服务器内部错误' :
        error.response?.status === 403 ? '访问被拒绝' :
        error.message?.includes('timeout') ? '请求超时' :
        error.message?.includes('Network Error') ? '网络连接错误' :
        '未知错误';
      
      simulationMessage.value = `模拟失败: ${errorMessage}。正在加载模拟数据...`
      
      // 生成模拟数据用于演示
      setTimeout(() => {
        simulationResults.value = generateMockResults(error.response?.status || error.message)
      }, 500)
    } finally {
      isSimulating.value = false
      simulationProgress.value = simulationResults.value.length > 0 ? 100 : 0
    }
  } catch (error) {
    // 这是外层的错误处理，处理意外情况
    console.error('模拟意外错误:', error)
    simulationError.value = '发生了意外错误，请刷新页面重试'
    isSimulating.value = false
    simulationProgress.value = 0
  }
}

// 判断事件是否有详情数据(状态、属性、奖励等)
const hasEventDetails = (event) => {
  return event.stats || event.reward || event.state || 
         event.attributes || event.properties || event.rewards
}

// 格式化数值，处理对象、数组等格式
const formatValue = (value) => {
  if (value === null || value === undefined) return '-'
  if (typeof value === 'object') return JSON.stringify(value)
  return value
}

// 修改generateMockResults函数，设置标志位
const generateMockResults = (errorType = null) => {
  usingMockData.value = true
  const results = []
  const totalSteps = simulationSteps.value
  const events = ['找到工作', '结识新朋友', '搬家', '失恋', '加薪', '生病', '旅行', '学习新技能']
  const stats = ['幸福度', '健康', '财富', '社交', '智慧']
  
  // 生成事件数量
  const numEvents = Math.min(10, Math.max(3, Math.floor(totalSteps / 10)))
  
  for (let i = 0; i < numEvents; i++) {
    const step = Math.floor(totalSteps / numEvents * (i + 1))
    const eventStats = {}
    
    stats.forEach(stat => {
      eventStats[stat] = Math.floor(Math.random() * 100)
    })
    
    const eventTitle = events[Math.floor(Math.random() * events.length)]
    
    results.push({
      step,
      title: eventTitle,
      description: `这是一个模拟的命运事件描述 "${eventTitle}"。在实际应用中，这里将显示有关角色经历的详细信息。`,
      stats: eventStats,
      is_mock: true
    })
  }
  
  return results
}

// 重置模拟
const resetSimulation = () => {
  console.log('重置模拟结果')
  simulationResults.value = []
  simulationProgress.value = 0
  simulationMessage.value = ''
  simulationError.value = null
  showDebug.value = false
  usingMockData.value = false
}
</script>

<style scoped>
.simulation {
  padding: 20px;
}

h1 {
  margin-bottom: 30px;
  color: var(--color-primary);
}

.simulation-container {
  display: flex;
  flex-direction: column;
  gap: 20px;
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.simulation-controls {
  background-color: #f8f9fa;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.simulation-controls h2 {
  margin-top: 0;
  color: #333;
  border-bottom: 1px solid #ddd;
  padding-bottom: 10px;
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 15px;
}

.form-group label {
  display: block;
  margin-bottom: 5px;
  font-weight: 500;
}

.form-group select,
.form-group input {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 14px;
}

.actions {
  display: flex;
  gap: 10px;
  margin-top: 20px;
}

.actions button {
  padding: 8px 16px;
  border: none;
  border-radius: 4px;
  background-color: #4a6fa5;
  color: white;
  cursor: pointer;
  font-weight: 500;
  transition: background-color 0.2s;
}

.actions button:hover:not(:disabled) {
  background-color: #3a5a80;
}

.actions button:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}

.status-message {
  margin-top: 15px;
  padding: 10px;
  border-radius: 4px;
  background-color: #e8f4f8;
  color: #2c6a8c;
}

.error-message {
  margin-top: 15px;
  padding: 10px;
  border-radius: 4px;
  background-color: #ffeaea;
  color: #cc0000;
  border-left: 4px solid #cc0000;
}

.progress-bar {
  margin-top: 15px;
  height: 20px;
  background-color: #eee;
  border-radius: 10px;
  overflow: hidden;
  position: relative;
}

.progress-fill {
  height: 100%;
  background-color: #4caf50;
  transition: width 0.3s ease;
}

.progress-text {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  line-height: 20px;
  text-align: center;
  color: white;
  font-weight: 500;
  text-shadow: 0 0 2px rgba(0, 0, 0, 0.5);
}

.simulation-results {
  background-color: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.simulation-results h2 {
  margin-top: 0;
  color: #333;
  border-bottom: 1px solid #ddd;
  padding-bottom: 10px;
  margin-bottom: 20px;
}

.mock-data-notice {
  background-color: #fff3cd;
  color: #856404;
  padding: 10px;
  border-radius: 4px;
  margin-bottom: 20px;
  border-left: 4px solid #ffc107;
}

.events-container {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
  margin-bottom: 20px;
}

.event-card {
  border: 1px solid #eee;
  border-radius: 8px;
  padding: 15px;
  background-color: #fff;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12);
  transition: transform 0.2s, box-shadow 0.2s;
}

.event-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.event-header {
  margin-bottom: 10px;
}

.event-step {
  background-color: #4a6fa5;
  color: white;
  padding: 2px 6px;
  border-radius: 3px;
  font-size: 12px;
  display: inline-block;
  margin-bottom: 5px;
}

.event-title {
  margin: 0;
  color: #333;
  font-size: 18px;
}

.event-description {
  color: #555;
  margin-bottom: 15px;
  line-height: 1.5;
}

.event-stats, 
.event-rewards, 
.event-state {
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px solid #eee;
}

.event-stats h4, 
.event-rewards h4, 
.event-state h4 {
  margin: 0 0 8px 0;
  font-size: 14px;
  color: #555;
}

.event-stats ul, 
.event-rewards ul, 
.event-state ul {
  margin: 0;
  padding: 0 0 0 20px;
}

.event-stats li, 
.event-rewards li, 
.event-state li {
  margin-bottom: 4px;
  font-size: 14px;
}

.debug-section {
  margin-top: 20px;
  border-top: 1px solid #eee;
  padding-top: 20px;
}

.debug-toggle {
  background-color: #f8f9fa;
  border: 1px solid #ddd;
  padding: 5px 10px;
  border-radius: 4px;
  cursor: pointer;
}

.debug-info {
  margin-top: 10px;
  background-color: #f8f9fa;
  padding: 15px;
  border-radius: 4px;
  overflow: auto;
  max-height: 300px;
  font-family: monospace;
  font-size: 12px;
  white-space: pre-wrap;
}

.empty-state, .loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 300px;
  color: #666;
}

.timeline {
  position: relative;
  margin: 20px 0;
  padding-left: 30px;
}

.timeline:before {
  content: '';
  position: absolute;
  left: 10px;
  top: 0;
  height: 100%;
  width: 2px;
  background: var(--color-primary);
}

.timeline-event {
  position: relative;
  margin-bottom: 30px;
}

.timeline-event:before {
  content: '';
  position: absolute;
  left: -30px;
  top: 0;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: var(--color-primary);
}

.event-time {
  font-weight: bold;
  margin-bottom: 5px;
  color: var(--color-secondary);
}

.event-content {
  background: white;
  padding: 15px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.stats {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: 10px;
}

.stat-item {
  background: #f0f0f0;
  padding: 5px 10px;
  border-radius: 20px;
  font-size: 0.9em;
}

.btn.secondary {
  background-color: #666;
  color: white;
  margin-top: 10px;
}

.btn.secondary:hover:not(:disabled) {
  background-color: #333;
}

@media (max-width: 768px) {
  .simulation-container {
    flex-direction: column;
  }
}
</style> 