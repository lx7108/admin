<template>
  <div class="user-view">
    <div v-if="isLoggedIn">
      <div class="user-profile">
        <h1>个人中心</h1>
        <div class="user-info">
          <h3>用户信息</h3>
          <div class="info-item">
            <span class="label">用户名:</span>
            <span class="value">{{ userInfo.username }}</span>
          </div>
          <div class="info-item">
            <span class="label">邮箱:</span>
            <span class="value">{{ userInfo.email }}</span>
          </div>
          <div class="info-item">
            <span class="label">角色数量:</span>
            <span class="value">{{ characters.length }}</span>
          </div>
        </div>
        
        <div class="characters-section">
          <h3>我的角色</h3>
          <div v-if="!characters.length" class="empty-state">
            您还没有创建角色，去<router-link to="/character">角色管理</router-link>创建一个吧！
          </div>
          <div v-else class="character-list">
            <div v-for="char in characters" :key="char.id" class="character-card">
              <div class="avatar">
                <img v-if="char.avatar_url" :src="char.avatar_url" alt="头像">
                <div v-else class="default-avatar">{{ char.name.charAt(0) }}</div>
              </div>
              <div class="character-info">
                <h4>{{ char.name }}</h4>
                <p class="fate-score">命运评分: {{ char.fate_score }}</p>
              </div>
            </div>
          </div>
        </div>
        
        <button @click="logout" class="btn danger">退出登录</button>
      </div>
    </div>
    
    <div v-else>
      <UserLogin v-if="currentView === 'login'" 
        @login-success="handleLoginSuccess" 
        @show-register="currentView = 'register'" 
      />
      
      <UserRegister v-else 
        @register-success="handleRegisterSuccess" 
        @show-login="currentView = 'login'" 
      />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import UserLogin from '../components/UserLogin.vue'
import UserRegister from '../components/UserRegister.vue'
import { authService } from '../services/auth'
import { apiService } from '../services/api'

const router = useRouter()
const isLoggedIn = ref(false)
const currentView = ref('login')
const userInfo = ref({})
const characters = ref([])

// 页面加载时检查登录状态
onMounted(async () => {
  checkLoginStatus()
})

// 检查登录状态
const checkLoginStatus = async () => {
  if (authService.isLoggedIn()) {
    try {
      // 获取用户信息
      const user = await authService.getCurrentUser()
      if (user) {
        userInfo.value = user
        isLoggedIn.value = true
        
        // 获取用户角色
        fetchUserCharacters()
      } else {
        // 获取用户信息失败，可能是token无效
        authService.logout()
        isLoggedIn.value = false
      }
    } catch (error) {
      console.error('获取用户信息失败:', error)
      authService.logout()
      isLoggedIn.value = false
    }
  } else {
    isLoggedIn.value = false
  }
}

// 获取用户角色
const fetchUserCharacters = async () => {
  try {
    const data = await apiService.getUserCharacters()
    if (data && data.characters) {
      characters.value = data.characters
    }
  } catch (error) {
    console.error('获取用户角色失败:', error)
    characters.value = []
  }
}

// 登录成功处理
const handleLoginSuccess = async () => {
  await checkLoginStatus()
  router.push('/')
}

// 注册成功处理
const handleRegisterSuccess = () => {
  currentView.value = 'login'
}

// 退出登录
const logout = () => {
  authService.logout()
  isLoggedIn.value = false
  userInfo.value = {}
  characters.value = []
}
</script>

<style scoped>
.user-view {
  padding: 20px;
  max-width: 900px;
  margin: 0 auto;
}

h1 {
  color: var(--color-primary);
  margin-bottom: 30px;
}

.user-profile {
  background: #f9f9f9;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.user-info {
  margin-bottom: 30px;
  padding: 20px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.info-item {
  display: flex;
  margin-bottom: 10px;
  padding-bottom: 10px;
  border-bottom: 1px solid #eee;
}

.info-item:last-child {
  border-bottom: none;
}

.label {
  font-weight: bold;
  width: 100px;
}

.value {
  flex: 1;
}

.characters-section {
  margin-bottom: 30px;
}

.character-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 20px;
  margin-top: 20px;
}

.character-card {
  background: white;
  border-radius: 8px;
  padding: 15px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.05);
  display: flex;
  align-items: center;
  transition: transform 0.2s;
}

.character-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.avatar {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  overflow: hidden;
  margin-right: 15px;
}

.avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.default-avatar {
  width: 100%;
  height: 100%;
  background: var(--color-primary);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
}

.character-info h4 {
  margin: 0 0 5px 0;
}

.fate-score {
  margin: 0;
  font-size: 0.9rem;
  color: #666;
}

.empty-state {
  padding: 20px;
  text-align: center;
  color: #666;
}

.btn {
  display: inline-block;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: bold;
  transition: background-color 0.3s;
}

.btn.danger {
  background-color: #ff3860;
  color: white;
}

.btn.danger:hover {
  background-color: #ff1443;
}
</style> 