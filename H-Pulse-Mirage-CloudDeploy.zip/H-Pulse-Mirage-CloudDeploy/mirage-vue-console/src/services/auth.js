import { apiService } from './api'

// 认证服务
export const authService = {
  // 登录并保存令牌
  async login(username, password) {
    try {
      const data = await apiService.loginUser(username, password)
      if (data.access_token) {
        localStorage.setItem('token', data.access_token)
        return true
      }
      return false
    } catch (error) {
      console.error('登录失败:', error)
      return false
    }
  },
  
  // 注册新用户
  async register(userData) {
    try {
      const user = await apiService.registerUser(userData)
      return user
    } catch (error) {
      console.error('注册失败:', error)
      throw error
    }
  },
  
  // 获取当前用户信息
  async getCurrentUser() {
    try {
      return await apiService.getCurrentUser()
    } catch (error) {
      console.error('获取用户信息失败:', error)
      return null
    }
  },
  
  // 检查是否已登录
  isLoggedIn() {
    return !!localStorage.getItem('token')
  },
  
  // 登出
  logout() {
    localStorage.removeItem('token')
  }
}

export default authService 