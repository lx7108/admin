<template>
  <div class="login-form">
    <h2>用户登录</h2>
    <form @submit.prevent="login">
      <div class="form-group">
        <label for="username">用户名或邮箱</label>
        <input 
          id="username" 
          v-model="username" 
          type="text" 
          required 
          placeholder="请输入用户名或邮箱"
        />
      </div>
      
      <div class="form-group">
        <label for="password">密码</label>
        <input 
          id="password" 
          v-model="password" 
          type="password" 
          required 
          placeholder="请输入密码"
        />
      </div>
      
      <div v-if="errorMessage" class="error-message">
        {{ errorMessage }}
      </div>
      
      <button type="submit" class="btn primary" :disabled="isLoading">
        {{ isLoading ? '登录中...' : '登录' }}
      </button>
      
      <div class="register-link">
        <span>还没有账号？</span>
        <a href="#" @click.prevent="showRegister">立即注册</a>
      </div>
    </form>
  </div>
</template>

<script setup>
import { ref, defineEmits } from 'vue'
import { authService } from '../services/auth'

const emit = defineEmits(['login-success', 'show-register'])

const username = ref('')
const password = ref('')
const errorMessage = ref('')
const isLoading = ref(false)

const login = async () => {
  if (!username.value || !password.value) {
    errorMessage.value = '请输入用户名和密码'
    return
  }
  
  isLoading.value = true
  errorMessage.value = ''
  
  try {
    const success = await authService.login(username.value, password.value)
    if (success) {
      emit('login-success')
    } else {
      errorMessage.value = '登录失败，请检查用户名和密码'
    }
  } catch (error) {
    console.error('登录发生错误:', error)
    errorMessage.value = '登录失败，请稍后再试'
  } finally {
    isLoading.value = false
  }
}

const showRegister = () => {
  emit('show-register')
}
</script>

<style scoped>
.login-form {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  background: #f9f9f9;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

h2 {
  text-align: center;
  color: var(--color-primary);
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 15px;
}

label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}

input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.error-message {
  color: #ff3860;
  margin: 10px 0;
}

.btn {
  display: block;
  width: 100%;
  padding: 10px;
  margin-top: 15px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: bold;
  transition: background-color 0.3s;
}

.btn.primary {
  background-color: var(--color-primary);
  color: white;
}

.btn.primary:hover:not(:disabled) {
  background-color: #3aa876;
}

.btn:disabled {
  background-color: #cccccc;
  cursor: not-allowed;
}

.register-link {
  text-align: center;
  margin-top: 15px;
}

.register-link a {
  color: var(--color-primary);
  text-decoration: none;
}

.register-link a:hover {
  text-decoration: underline;
}
</style> 