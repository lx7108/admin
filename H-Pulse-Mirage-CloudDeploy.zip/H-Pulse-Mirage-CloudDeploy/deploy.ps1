# 部署配置
$SERVER_IP = "8.148.68.190"
$SERVER_USER = "root"
$DEPLOY_DIR = "H-Pulse-Mirage-CloudDeploy"
$LOCAL_ZIP = "$DEPLOY_DIR.zip"

Write-Host "🚀 开始部署 H-Pulse·Mirage 到云服务器 $SERVER_IP..." -ForegroundColor Cyan

# 创建部署目录
Write-Host "📂 创建临时部署目录..." -ForegroundColor Yellow
New-Item -ItemType Directory -Path $DEPLOY_DIR -Force | Out-Null

# 复制必要文件
Write-Host "📋 复制项目文件..." -ForegroundColor Yellow
Copy-Item -Path "mirage-vue-console" -Destination "$DEPLOY_DIR/" -Recurse -Force
Copy-Item -Path "mirage-backend-full" -Destination "$DEPLOY_DIR/" -Recurse -Force
Copy-Item -Path "docker-compose.yml" -Destination "$DEPLOY_DIR/" -Force
Copy-Item -Path "Dockerfile.frontend" -Destination "$DEPLOY_DIR/" -Force
Copy-Item -Path "Dockerfile.backend" -Destination "$DEPLOY_DIR/" -Force
Copy-Item -Path "init_postgres.sql" -Destination "$DEPLOY_DIR/" -Force
Copy-Item -Path "init_server.sh" -Destination "$DEPLOY_DIR/" -Force

# 打包文件
Write-Host "📦 打包项目文件..." -ForegroundColor Yellow
if (Test-Path $LOCAL_ZIP) {
    Remove-Item $LOCAL_ZIP -Force
}
Compress-Archive -Path $DEPLOY_DIR -DestinationPath $LOCAL_ZIP

# 设置SSH连接信息
Write-Host "⚠️ 云服务器部署需要使用SSH连接，请确保您已设置好SSH密钥" -ForegroundColor Red
Write-Host "📤 请手动上传 $LOCAL_ZIP 到服务器，然后在服务器上运行以下命令:" -ForegroundColor Green
Write-Host "   unzip $LOCAL_ZIP -d ~/" -ForegroundColor Yellow
Write-Host "   cd ~/$DEPLOY_DIR" -ForegroundColor Yellow
Write-Host "   bash init_server.sh" -ForegroundColor Yellow

Write-Host "✅ 本地打包完成！" -ForegroundColor Green
Write-Host "🌐 部署完成后，前端访问地址: http://$SERVER_IP:4173" -ForegroundColor Cyan
Write-Host "🌐 部署完成后，后端API地址: http://$SERVER_IP:8000/api" -ForegroundColor Cyan 