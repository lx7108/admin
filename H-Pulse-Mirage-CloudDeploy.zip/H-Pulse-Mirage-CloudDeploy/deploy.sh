#!/bin/bash

# 部署配置
SERVER_IP="8.148.68.190"
SERVER_USER="root"
DEPLOY_DIR="H-Pulse-Mirage-CloudDeploy"
LOCAL_ZIP="$DEPLOY_DIR.zip"

echo "🚀 开始部署 H-Pulse·Mirage 到云服务器 $SERVER_IP..."

# 创建部署目录
echo "📂 创建临时部署目录..."
mkdir -p $DEPLOY_DIR

# 复制必要文件
echo "📋 复制项目文件..."
cp -r mirage-vue-console $DEPLOY_DIR/
cp -r mirage-backend-full $DEPLOY_DIR/
cp docker-compose.yml $DEPLOY_DIR/
cp Dockerfile.frontend $DEPLOY_DIR/
cp Dockerfile.backend $DEPLOY_DIR/
cp init_postgres.sql $DEPLOY_DIR/
cp init_server.sh $DEPLOY_DIR/

# 打包文件
echo "📦 打包项目文件..."
zip -r $LOCAL_ZIP $DEPLOY_DIR

# 上传到服务器
echo "📤 上传到服务器..."
scp $LOCAL_ZIP $SERVER_USER@$SERVER_IP:~/$LOCAL_ZIP

# 执行部署脚本
echo "🔧 执行部署脚本..."
ssh $SERVER_USER@$SERVER_IP "cd ~ && bash -s" < init_server.sh

# 清理本地文件
echo "🧹 清理本地临时文件..."
rm -rf $DEPLOY_DIR $LOCAL_ZIP

echo "✅ 部署完成！"
echo "🌐 前端访问地址: http://$SERVER_IP:4173"
echo "🌐 后端API地址: http://$SERVER_IP:8000/api"
echo ""
echo "💡 提示: 如需查看日志，请使用以下命令:"
echo "  ssh $SERVER_USER@$SERVER_IP \"docker logs -f h-pulse-mirage-clouddeploy-frontend-1\""
echo "  ssh $SERVER_USER@$SERVER_IP \"docker logs -f h-pulse-mirage-clouddeploy-backend-1\"" 