#!/bin/bash
# 修改源代码并重新构建

# 停止容器
echo "停止所有容器..."
docker compose down

# 检查源码文件
echo "检查源码文件..."
DB_FILE="mirage-backend-full/backend/app/database.py"

if [ ! -f "$DB_FILE" ]; then
  echo "错误：找不到源码文件 $DB_FILE"
  exit 1
fi

# 修改源码文件
echo "尝试修改源码文件..."
if grep -q "@event.listens_for(engine, \"disconnect\")" "$DB_FILE"; then
  echo "发现错误的事件名称，正在修复源码..."
  # 创建备份
  cp "$DB_FILE" "${DB_FILE}.bak"
  
  # 替换错误的事件名
  sed -i 's/@event.listens_for(engine, "disconnect")/@event.listens_for(engine, "close")/g' "$DB_FILE"
  sed -i 's/def disconnect(/def close_connection(/g' "$DB_FILE"
  
  echo "源码修复完成！"
  
  # 验证修复
  if grep -q "@event.listens_for(engine, \"disconnect\")" "$DB_FILE"; then
    echo "错误：修复失败，源码中仍然存在错误的事件名称"
    # 恢复备份
    mv "${DB_FILE}.bak" "$DB_FILE"
    exit 1
  fi
  
  # 清理备份
  rm -f "${DB_FILE}.bak"
else
  echo "源码文件中事件名称正确，无需修复"
fi

# 确保Dockerfile也包含修复代码
echo "更新Dockerfile.backend..."
if ! grep -q "确认database.py文件中的事件监听器是否正确" "Dockerfile.backend"; then
  # 在适当位置添加修复代码
  sed -i '/尝试测试数据库连接/,/exit 1/a \\n# 确认database.py文件中的事件监听器是否正确\\nif grep -q "disconnect" /app/backend/app/database.py; then\\n  echo "发现错误的事件名称，尝试修复..."\\n  sed -i "s/@event.listens_for(engine, \\"disconnect\\")/@event.listens_for(engine, \\"close\\")/g" /app/backend/app/database.py\\n  sed -i "s/def disconnect(/def close_connection(/g" /app/backend/app/database.py\\n  echo "修复完成，重新检查..."\\n  if grep -q "disconnect" /app/backend/app/database.py; then\\n    echo "修复失败，依然存在错误，退出..."\\n    exit 1\\n  fi\\nfi' "Dockerfile.backend"
  
  echo "Dockerfile.backend更新完成！"
fi

# 清理Docker缓存
echo "清理Docker缓存..."
docker builder prune -f

# 重新构建并启动容器
echo "重新构建并启动容器..."
docker compose up -d --build

# 等待容器启动
echo "等待容器启动..."
sleep 15

# 查看容器状态
echo "查看容器状态..."
docker ps -a

# 查看后端日志
echo "查看后端日志..."
docker logs h-pulse-mirage-clouddeploy-backend-1

echo "修复流程完成！" 