#!/bin/bash

# 创建docker配置目录
mkdir -p /etc/docker

# 配置镜像加速器
cat > /etc/docker/daemon.json << EOF
{
  "registry-mirrors": [
    "https://registry.docker-cn.com",
    "https://docker.mirrors.ustc.edu.cn", 
    "https://hub-mirror.c.163.com"
  ]
}
EOF

# 重启Docker服务
systemctl daemon-reload
systemctl restart docker

echo "Docker镜像加速器配置完成" 