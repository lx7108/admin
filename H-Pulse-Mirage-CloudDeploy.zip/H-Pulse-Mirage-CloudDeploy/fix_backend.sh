#!/bin/bash
# 停止所有容器
docker compose down

# 尝试直接修改源码文件
echo "正在检查源码文件..."
if [ -f "mirage-backend-full/backend/app/database.py" ]; then
  echo "找到数据库文件，正在检查..."
  if grep -q "disconnect" mirage-backend-full/backend/app/database.py; then
    echo "发现错误的事件名称，正在修复..."
    sed -i 's/@event.listens_for(engine, "disconnect")/@event.listens_for(engine, "close")/g' mirage-backend-full/backend/app/database.py
    sed -i 's/def disconnect(/def close_connection(/g' mirage-backend-full/backend/app/database.py
    echo "源码文件修复完成!"
  else
    echo "源码文件已经是正确的，无需修复。"
  fi
else
  echo "未找到源码文件，跳过此步骤。"
fi

# 添加运行时修复脚本到容器
echo "正在更新Dockerfile.backend的start.sh脚本..."
if grep -q "检查database.py文件中的事件监听器" Dockerfile.backend; then
  echo "Dockerfile.backend已包含修复代码，无需更新。"
else
  echo "正在修改Dockerfile.backend添加自动修复代码..."
  # 在特定位置插入修复代码
  sed -i '/尝试测试数据库连接/,/exit 1/a \\n# 检查database.py文件中的事件监听器是否正确\\nif grep -q "disconnect" /app/backend/app/database.py; then\\n  echo "修复database.py文件中的事件监听器..."\\n  sed -i "s/@event.listens_for(engine, \\"disconnect\\")/@event.listens_for(engine, \\"close\\")/g" /app/backend/app/database.py\\n  sed -i "s/def disconnect(/def close_connection(/g" /app/backend/app/database.py\\nfi' Dockerfile.backend
  echo "Dockerfile.backend更新完成!"
fi

# 清理Docker缓存
echo "清理Docker缓存..."
docker builder prune -f

# 重新构建并运行容器
echo "重新构建并启动容器..."
docker compose up -d --build

# 等待容器启动
echo "等待容器启动..."
sleep 10

# 查看后端容器状态
echo "检查后端容器状态..."
docker ps -a | grep backend

# 查看后端日志
echo "查看后端日志..."
docker logs h-pulse-mirage-clouddeploy-backend-1

echo "修复流程完成!" 