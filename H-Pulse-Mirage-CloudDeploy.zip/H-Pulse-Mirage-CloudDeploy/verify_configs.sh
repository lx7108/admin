#!/bin/bash
set -e

echo "🔍 开始验证配置文件..."

# 检查必要文件是否存在
echo "📂 检查必要文件..."
REQUIRED_FILES=(
  "docker-compose.yml"
  "Dockerfile.backend"
  "Dockerfile.frontend"
  "nginx.conf"
  "nginx-full.conf"
  "nginx-ssl.conf"
  "frontend-start.sh"
  "init_server.sh"
  "setup_domain.sh"
  "one_click_deploy.sh"
)

for file in "${REQUIRED_FILES[@]}"; do
  if [ ! -f "$file" ]; then
    echo "❌ 错误: 缺少必要文件 $file"
    exit 1
  else
    echo "✅ 文件存在: $file"
  fi
done

# 检查Docker Compose文件语法
echo "🔍 验证docker-compose.yml语法..."
if command -v docker-compose &> /dev/null; then
  docker-compose config -q && echo "✅ Docker Compose配置有效" || { echo "❌ Docker Compose配置无效"; exit 1; }
else
  echo "⚠️ 警告: docker-compose命令不可用，跳过验证"
fi

# 检查shell脚本语法
echo "🔍 验证shell脚本语法..."
for script in *.sh; do
  if [ -f "$script" ]; then
    bash -n "$script" && echo "✅ 脚本语法正确: $script" || { echo "❌ 脚本语法错误: $script"; exit 1; }
  fi
done

# 检查Nginx配置语法(如果有nginx命令)
echo "🔍 验证Nginx配置语法..."
if command -v nginx &> /dev/null; then
  for conf in *.conf; do
    if [ -f "$conf" ]; then
      nginx -t -c "$(pwd)/$conf" 2>/dev/null && echo "✅ Nginx配置有效: $conf" || echo "⚠️ Nginx配置可能有问题: $conf (这可能是正常的，因为配置可能依赖于环境变量或其他文件)"
    fi
  done
else
  echo "⚠️ 警告: nginx命令不可用，跳过验证"
fi

# 检查环境变量文件格式
echo "🔍 验证环境变量配置..."
if [ -f "mirage-vue-console/.env" ]; then
  grep -v "^#" mirage-vue-console/.env | grep "=" > /dev/null && echo "✅ 前端环境变量格式正确" || { echo "❌ 前端环境变量格式错误"; exit 1; }
fi

if [ -f "mirage-vue-console/.env.production" ]; then
  grep -v "^#" mirage-vue-console/.env.production | grep "=" > /dev/null && echo "✅ 前端生产环境变量格式正确" || { echo "❌ 前端生产环境变量格式错误"; exit 1; }
fi

# 检查项目目录结构
echo "🔍 验证项目结构..."
if [ -d "mirage-vue-console" ]; then
  echo "✅ 前端目录存在"
else
  echo "❌ 错误: 缺少前端代码目录"
  exit 1
fi

if [ -d "mirage-backend-full" ]; then
  echo "✅ 后端目录存在"
else
  echo "❌ 错误: 缺少后端代码目录"
  exit 1
fi

echo "✅ 所有配置验证通过!"
echo "📝 注意: 此脚本仅检查基本语法和文件存在性，部署前请确保服务器环境满足要求。" 