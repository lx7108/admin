#!/bin/bash

# 停止当前运行的容器
docker compose down

# 创建临时容器来修复文件
cat > temp_fix.py << 'EOF'
#!/usr/bin/env python3
import sys

def fix_database_file(file_path):
    with open(file_path, 'r') as file:
        content = file.read()
    
    # 替换 'disconnect' 事件为 'close' 事件
    fixed_content = content.replace(
        '@event.listens_for(engine, "disconnect")\ndef disconnect(dbapi_connection, connection_record):',
        '@event.listens_for(engine, "close")\ndef close_connection(dbapi_connection, connection_record):'
    )
    
    with open(file_path, 'w') as file:
        file.write(fixed_content)
    
    print(f"文件 {file_path} 已成功修复!")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        fix_database_file(sys.argv[1])
    else:
        print("请提供数据库文件路径!")
        sys.exit(1)
EOF

# 构建一个临时镜像来修复文件
cat > Dockerfile.fix << 'EOF'
FROM h-pulse-mirage-clouddeploy-backend

COPY temp_fix.py /app/temp_fix.py
RUN chmod +x /app/temp_fix.py

# 修复数据库文件
RUN python /app/temp_fix.py /app/backend/app/database.py

# 显示修复后的文件
RUN cat /app/backend/app/database.py | grep -A 2 -B 2 "listens_for.*close"
EOF

# 构建修复镜像
docker build -t backend-fixed -f Dockerfile.fix .

# 标记修复后的镜像
docker tag backend-fixed h-pulse-mirage-clouddeploy-backend

# 删除临时文件
rm -f temp_fix.py Dockerfile.fix

# 重启服务
docker compose up -d

echo "修复完成! 后端服务已重启。" 