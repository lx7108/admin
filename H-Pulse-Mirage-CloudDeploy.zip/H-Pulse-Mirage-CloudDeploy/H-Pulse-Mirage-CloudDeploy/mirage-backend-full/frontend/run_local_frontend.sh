#!/bin/bash
echo "正在启动 H-Pulse 前端（本地开发模式）..."

cd h-pulse-frontend
npm install
npm run dev
