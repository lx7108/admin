#!/bin/bash

echo "🚀 正在初始化云服务器环境..."

# 安装 Docker
if ! command -v docker &> /dev/null
then
    echo "📦 安装 Docker..."
    curl -fsSL https://get.docker.com | bash
fi

# 安装 Docker Compose
if ! command -v docker-compose &> /dev/null
then
    echo "📦 安装 Docker Compose..."
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
fi

# 启动服务（直接在当前目录）
echo "🚀 启动服务..."
docker compose up --build -d

# 等待服务启动
echo "⏳ 等待服务启动..."
sleep 10

# 检查服务状态
echo "🔍 检查服务状态..."
docker ps

# 设置防火墙（如果需要）
echo "🔧 确保端口开放..."
if command -v ufw &> /dev/null; then
    ufw allow 4173/tcp
    ufw allow 8000/tcp
    echo "✅ 防火墙已配置"
fi

SERVER_IP=$(curl -s ifconfig.me)
echo "✅ 部署完成！"
echo "🌐 前端访问地址: http://$SERVER_IP:4173"
echo "🌐 后端API地址: http://$SERVER_IP:8000/api"