import axios from 'axios'

// 根据环境获取API基础URL
const baseURL = import.meta.env.VITE_API_BASE_URL || '/api'

// 创建axios实例
const apiClient = axios.create({
  baseURL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
})

// 请求拦截器
apiClient.interceptors.request.use(
  config => {
    // 如果有token，可以在这里添加到请求头
    const token = localStorage.getItem('token')
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`
    }
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

// 响应拦截器
apiClient.interceptors.response.use(
  response => response.data,
  error => {
    console.error('API请求错误:', error)
    return Promise.reject(error)
  }
)

// API服务
export const apiService = {
  // 健康检查
  checkHealth() {
    return apiClient.get('/health')
  },
  
  // 角色相关
  getCharacters() {
    return apiClient.get('/character/list')
  },
  
  getCharacter(id) {
    return apiClient.get(`/character/${id}`)
  },
  
  createCharacter(data) {
    return apiClient.post('/character/create', data)
  },
  
  updateCharacter(id, data) {
    return apiClient.put(`/character/${id}`, data)
  },
  
  deleteCharacter(id) {
    return apiClient.delete(`/character/${id}`)
  },
  
  // 模拟相关
  runSimulation(data) {
    return apiClient.post('/simulation/run', data)
  },
  
  // 剧场相关
  getScenes() {
    return apiClient.get('/theater/scenes')
  },
  
  getScene(id) {
    return apiClient.get(`/theater/scene/${id}`)
  },
  
  startTheater(data) {
    return apiClient.post('/theater/start', data)
  },
  
  nextTheaterDialog(data) {
    return apiClient.post('/theater/next', data)
  }
}

export default apiService 