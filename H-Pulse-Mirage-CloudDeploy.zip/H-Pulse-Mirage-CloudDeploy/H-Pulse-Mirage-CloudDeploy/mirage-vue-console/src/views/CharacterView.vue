<template>
  <div class="character">
    <h1>角色管理</h1>
    
    <div class="action-bar">
      <button class="btn primary" @click="showCreateForm = true">创建新角色</button>
    </div>
    
    <div class="character-list" v-if="characters.length">
      <div v-for="character in characters" :key="character.id" class="character-card">
        <div class="character-avatar">
          <img :src="character.avatar || '/placeholder-avatar.svg'" alt="Character Avatar">
        </div>
        <div class="character-info">
          <h3>{{ character.name }}</h3>
          <p class="attributes">
            <span>命格: {{ character.fate_score || 0 }}</span>
            <span>健康: {{ character.health || 0 }}</span>
            <span>智慧: {{ character.wisdom || 0 }}</span>
          </p>
          <p class="description">{{ character.description || '暂无描述' }}</p>
        </div>
        <div class="character-actions">
          <button class="btn small" @click="editCharacter(character)">编辑</button>
          <button class="btn small danger" @click="deleteCharacter(character.id)">删除</button>
        </div>
      </div>
    </div>
    
    <div class="empty-state" v-else>
      <p>暂无角色数据，请创建新角色</p>
    </div>
    
    <!-- 创建/编辑角色表单 -->
    <div class="modal" v-if="showCreateForm || editingCharacter">
      <div class="modal-content">
        <h2>{{ editingCharacter ? '编辑角色' : '创建新角色' }}</h2>
        
        <div class="form-group">
          <label>角色名称</label>
          <input type="text" v-model="formData.name" placeholder="请输入角色名称">
        </div>
        
        <div class="form-group">
          <label>角色描述</label>
          <textarea v-model="formData.description" rows="3" placeholder="请输入角色描述"></textarea>
        </div>
        
        <div class="attributes-grid">
          <div class="form-group">
            <label>命格</label>
            <input type="number" v-model.number="formData.fate_score" min="0" max="100">
          </div>
          
          <div class="form-group">
            <label>健康</label>
            <input type="number" v-model.number="formData.health" min="0" max="100">
          </div>
          
          <div class="form-group">
            <label>智慧</label>
            <input type="number" v-model.number="formData.wisdom" min="0" max="100">
          </div>
          
          <div class="form-group">
            <label>财富</label>
            <input type="number" v-model.number="formData.wealth" min="0" max="100">
          </div>
          
          <div class="form-group">
            <label>社交</label>
            <input type="number" v-model.number="formData.social" min="0" max="100">
          </div>
          
          <div class="form-group">
            <label>艺术</label>
            <input type="number" v-model.number="formData.art" min="0" max="100">
          </div>
        </div>
        
        <div class="modal-actions">
          <button class="btn secondary" @click="closeForm">取消</button>
          <button class="btn primary" @click="saveCharacter">保存</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, reactive } from 'vue'
import { apiService } from '../services/api'

const characters = ref([])
const showCreateForm = ref(false)
const editingCharacter = ref(null)

const formData = reactive({
  name: '',
  description: '',
  fate_score: 50,
  health: 50,
  wisdom: 50,
  wealth: 50,
  social: 50,
  art: 50
})

// 获取角色列表
onMounted(async () => {
  await loadCharacters()
})

const loadCharacters = async () => {
  try {
    const data = await apiService.getCharacters()
    characters.value = data || []
  } catch (error) {
    console.error('获取角色列表失败:', error)
    // 模拟数据
    characters.value = [
      {
        id: 1,
        name: '张三',
        description: '性格开朗，喜欢冒险',
        fate_score: 75,
        health: 80,
        wisdom: 65
      },
      {
        id: 2,
        name: '李四',
        description: '稳重踏实，精于谋略',
        fate_score: 60,
        health: 70,
        wisdom: 85
      }
    ]
  }
}

// 编辑角色
const editCharacter = (character) => {
  editingCharacter.value = character
  Object.keys(formData).forEach(key => {
    if (character[key] !== undefined) {
      formData[key] = character[key]
    }
  })
}

// 删除角色
const deleteCharacter = async (id) => {
  if (!confirm('确定要删除这个角色吗？此操作不可撤销！')) return
  
  try {
    await apiService.deleteCharacter(id)
    characters.value = characters.value.filter(c => c.id !== id)
  } catch (error) {
    console.error('删除角色失败:', error)
    // 模拟删除成功
    characters.value = characters.value.filter(c => c.id !== id)
  }
}

// 保存角色
const saveCharacter = async () => {
  try {
    if (editingCharacter.value) {
      // 编辑现有角色
      const data = await apiService.updateCharacter(editingCharacter.value.id, formData)
      const updatedIndex = characters.value.findIndex(c => c.id === editingCharacter.value.id)
      characters.value[updatedIndex] = data
    } else {
      // 创建新角色
      const data = await apiService.createCharacter(formData)
      characters.value.push(data)
    }
    
    closeForm()
  } catch (error) {
    console.error('保存角色失败:', error)
    
    // 模拟保存成功
    if (editingCharacter.value) {
      const updatedIndex = characters.value.findIndex(c => c.id === editingCharacter.value.id)
      characters.value[updatedIndex] = { ...editingCharacter.value, ...formData }
    } else {
      characters.value.push({
        id: Math.max(0, ...characters.value.map(c => c.id)) + 1,
        ...formData
      })
    }
    
    closeForm()
  }
}

// 关闭表单
const closeForm = () => {
  showCreateForm.value = false
  editingCharacter.value = null
  
  // 重置表单
  Object.keys(formData).forEach(key => {
    if (typeof formData[key] === 'string') {
      formData[key] = ''
    } else if (typeof formData[key] === 'number') {
      formData[key] = 50
    }
  })
}
</script>

<style scoped>
.character {
  padding: 20px;
}

h1 {
  margin-bottom: 30px;
  color: var(--color-primary);
}

.action-bar {
  margin-bottom: 20px;
}

.character-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
}

.character-card {
  background: #f9f9f9;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  display: flex;
  flex-direction: column;
}

.character-avatar {
  height: 150px;
  overflow: hidden;
  background: #eee;
}

.character-avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.character-info {
  padding: 15px;
  flex: 1;
}

.character-info h3 {
  margin-bottom: 10px;
  color: var(--color-secondary);
}

.attributes {
  display: flex;
  gap: 10px;
  margin-bottom: 10px;
}

.attributes span {
  background: #f0f0f0;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 0.9em;
}

.description {
  color: #666;
  font-size: 0.9em;
}

.character-actions {
  padding: 15px;
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  border-top: 1px solid #eee;
}

.btn {
  display: inline-block;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: bold;
  transition: background-color 0.3s;
}

.btn.small {
  padding: 6px 12px;
  font-size: 0.9em;
}

.btn.primary {
  background-color: var(--color-primary);
  color: white;
}

.btn.secondary {
  background-color: #e0e0e0;
  color: #333;
}

.btn.danger {
  background-color: #ff6b6b;
  color: white;
}

.btn.primary:hover {
  background-color: #3aa876;
}

.btn.secondary:hover {
  background-color: #d0d0d0;
}

.btn.danger:hover {
  background-color: #ff5252;
}

.empty-state {
  text-align: center;
  padding: 50px 0;
  color: #666;
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  padding: 30px;
  border-radius: 8px;
  width: 90%;
  max-width: 600px;
  max-height: 90vh;
  overflow-y: auto;
}

.modal-content h2 {
  margin-bottom: 20px;
  color: var(--color-secondary);
}

.form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 8px;
  font-weight: bold;
}

input, textarea {
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.attributes-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 15px;
}

.modal-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 20px;
}

@media (max-width: 768px) {
  .character-list {
    grid-template-columns: 1fr;
  }
  
  .attributes-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style> 