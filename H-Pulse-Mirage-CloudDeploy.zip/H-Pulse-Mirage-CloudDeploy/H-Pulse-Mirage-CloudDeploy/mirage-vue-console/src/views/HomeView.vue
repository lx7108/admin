<template>
  <div class="home">
    <div class="welcome-section">
      <h1>欢迎使用 H-Pulse·Mirage</h1>
      <p class="subtitle">命运模拟与演出引擎</p>
      
      <div class="features">
        <div class="feature-card">
          <h3>命运模拟</h3>
          <p>通过高级AI算法模拟角色命运轨迹</p>
          <router-link to="/simulation" class="btn">开始模拟</router-link>
        </div>
        
        <div class="feature-card">
          <h3>命运剧场</h3>
          <p>观看角色在特定场景中的表现</p>
          <router-link to="/theater" class="btn">进入剧场</router-link>
        </div>
        
        <div class="feature-card">
          <h3>角色管理</h3>
          <p>创建和管理您的角色</p>
          <router-link to="/character" class="btn">管理角色</router-link>
        </div>
      </div>
    </div>
    
    <div class="status-section">
      <h2>系统状态</h2>
      <div class="status-card">
        <div class="status-item">
          <span class="label">后端状态:</span>
          <span class="value" :class="{ 'online': backendStatus === 'online' }">
            {{ backendStatus === 'online' ? '在线' : '离线' }}
          </span>
        </div>
        <div class="status-item">
          <span class="label">数据库连接:</span>
          <span class="value" :class="{ 'online': dbStatus === 'connected' }">
            {{ dbStatus === 'connected' ? '已连接' : '未连接' }}
          </span>
        </div>
        <div class="status-item">
          <span class="label">服务器地址:</span>
          <span class="value online">8.148.68.190:8000</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { apiService } from '../services/api'

const backendStatus = ref('checking')
const dbStatus = ref('checking')

onMounted(async () => {
  try {
    const data = await apiService.checkHealth()
    backendStatus.value = 'online'
    dbStatus.value = data.db_connected ? 'connected' : 'disconnected'
  } catch (error) {
    console.error('Failed to fetch system status:', error)
    backendStatus.value = 'offline'
    dbStatus.value = 'disconnected'
  }
})
</script>

<style scoped>
.home {
  max-width: 1200px;
  margin: 0 auto;
}

.welcome-section {
  text-align: center;
  padding: 40px 0;
}

h1 {
  font-size: 2.5rem;
  color: var(--color-primary);
  margin-bottom: 0.5rem;
}

.subtitle {
  font-size: 1.2rem;
  color: var(--color-secondary);
  margin-bottom: 3rem;
}

.features {
  display: flex;
  justify-content: space-between;
  gap: 20px;
  margin-top: 40px;
}

.feature-card {
  flex: 1;
  background: #f9f9f9;
  border-radius: 8px;
  padding: 30px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
}

.feature-card:hover {
  transform: translateY(-5px);
}

.feature-card h3 {
  color: var(--color-primary);
  margin-bottom: 15px;
}

.btn {
  display: inline-block;
  margin-top: 20px;
  padding: 10px 20px;
  background-color: var(--color-primary);
  color: white;
  text-decoration: none;
  border-radius: 4px;
  transition: background-color 0.3s;
}

.btn:hover {
  background-color: #3aa876;
}

.status-section {
  margin-top: 60px;
  padding: 30px;
  background: #f5f5f5;
  border-radius: 8px;
}

.status-section h2 {
  margin-bottom: 20px;
  color: var(--color-secondary);
}

.status-card {
  background: white;
  padding: 20px;
  border-radius: 6px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.status-item {
  display: flex;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid #eee;
}

.status-item:last-child {
  border-bottom: none;
}

.label {
  font-weight: bold;
  color: #555;
}

.value {
  color: #ff4757;
}

.value.online {
  color: #2ed573;
}

@media (max-width: 768px) {
  .features {
    flex-direction: column;
  }
  
  .feature-card {
    margin-bottom: 20px;
  }
}
</style> 