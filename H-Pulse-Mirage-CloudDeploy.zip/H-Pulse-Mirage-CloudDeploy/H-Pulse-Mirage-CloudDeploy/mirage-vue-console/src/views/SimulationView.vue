<template>
  <div class="simulation">
    <h1>命运模拟</h1>
    
    <div class="simulation-container">
      <div class="control-panel">
        <h3>控制面板</h3>
        <div class="form-group">
          <label>选择角色</label>
          <select v-model="selectedCharacter">
            <option value="">请选择角色</option>
            <option v-for="char in characters" :key="char.id" :value="char.id">
              {{ char.name }}
            </option>
          </select>
        </div>
        
        <div class="form-group">
          <label>模拟步数</label>
          <input type="number" v-model.number="simulationSteps" min="10" max="1000" />
        </div>
        
        <div class="form-group">
          <label>随机种子</label>
          <input type="number" v-model.number="seed" placeholder="留空为随机" />
        </div>
        
        <button class="btn primary" @click="startSimulation" :disabled="!selectedCharacter || isSimulating">
          {{ isSimulating ? '模拟中...' : '开始模拟' }}
        </button>
      </div>
      
      <div class="simulation-results">
        <div v-if="!simulationResults.length && !isSimulating" class="empty-state">
          <p>选择角色并开始模拟以查看结果</p>
        </div>
        
        <div v-if="isSimulating" class="loading">
          <p>命运模拟中，请稍候...</p>
          <div class="progress-bar">
            <div class="progress" :style="{ width: simulationProgress + '%' }"></div>
          </div>
          <p class="progress-text">{{ simulationProgress }}%</p>
        </div>
        
        <div v-if="simulationResults.length && !isSimulating" class="results-list">
          <h3>模拟结果</h3>
          <div class="timeline">
            <div v-for="(event, index) in simulationResults" :key="index" class="timeline-event">
              <div class="event-time">第 {{ event.step }} 步</div>
              <div class="event-content">
                <h4>{{ event.title }}</h4>
                <p>{{ event.description }}</p>
                <div class="stats">
                  <span v-for="(value, key) in event.stats" :key="key" class="stat-item">
                    {{ key }}: {{ value }}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { apiService } from '../services/api'

const characters = ref([])
const selectedCharacter = ref('')
const simulationSteps = ref(100)
const seed = ref('')
const isSimulating = ref(false)
const simulationProgress = ref(0)
const simulationResults = ref([])

// 获取角色列表
onMounted(async () => {
  try {
    const data = await apiService.getCharacters()
    characters.value = data || []
  } catch (error) {
    console.error('获取角色列表失败:', error)
    characters.value = [
      { id: 1, name: '张三' },
      { id: 2, name: '李四' },
      { id: 3, name: '王五' }
    ]
  }
})

// 开始模拟
const startSimulation = async () => {
  if (!selectedCharacter.value || isSimulating.value) return
  
  isSimulating.value = true
  simulationProgress.value = 0
  simulationResults.value = []
  
  try {
    // 模拟进度更新
    const interval = setInterval(() => {
      if (simulationProgress.value < 95) {
        simulationProgress.value += 5
      }
    }, 300)
    
    // 调用模拟API
    const data = await apiService.runSimulation({
      character_id: selectedCharacter.value,
      steps: simulationSteps.value,
      seed: seed.value || Math.floor(Math.random() * 9999)
    })
    
    clearInterval(interval)
    simulationProgress.value = 100
    
    // 延迟显示结果，提供更好的用户体验
    setTimeout(() => {
      simulationResults.value = data?.events || []
      isSimulating.value = false
    }, 500)
    
  } catch (error) {
    console.error('模拟失败:', error)
    clearInterval(interval)
    isSimulating.value = false
    
    // 模拟数据用于演示
    setTimeout(() => {
      simulationResults.value = generateMockResults()
    }, 500)
  }
}

// 生成模拟数据（仅用于演示）
const generateMockResults = () => {
  const results = []
  const totalSteps = simulationSteps.value
  const events = ['找到工作', '结识新朋友', '搬家', '失恋', '加薪', '生病', '旅行', '学习新技能']
  const stats = ['幸福度', '健康', '财富', '社交', '智慧']
  
  for (let i = 0; i < 10; i++) {
    const step = Math.floor(totalSteps / 10 * (i + 1))
    const eventStats = {}
    
    stats.forEach(stat => {
      eventStats[stat] = Math.floor(Math.random() * 100)
    })
    
    results.push({
      step,
      title: events[Math.floor(Math.random() * events.length)],
      description: '这是一个随机生成的命运事件描述。在实际应用中，这里将显示有关角色经历的详细信息。',
      stats: eventStats
    })
  }
  
  return results
}
</script>

<style scoped>
.simulation {
  padding: 20px;
}

h1 {
  margin-bottom: 30px;
  color: var(--color-primary);
}

.simulation-container {
  display: flex;
  gap: 30px;
}

.control-panel {
  flex: 1;
  background: #f9f9f9;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.simulation-results {
  flex: 2;
  background: #f9f9f9;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  min-height: 500px;
}

.form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 8px;
  font-weight: bold;
}

select, input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.btn {
  display: inline-block;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: bold;
  transition: background-color 0.3s;
}

.btn.primary {
  background-color: var(--color-primary);
  color: white;
}

.btn.primary:hover:not(:disabled) {
  background-color: #3aa876;
}

.btn:disabled {
  background-color: #cccccc;
  cursor: not-allowed;
}

.empty-state, .loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 300px;
  color: #666;
}

.progress-bar {
  width: 80%;
  height: 20px;
  background-color: #ddd;
  border-radius: 10px;
  margin: 20px 0;
  overflow: hidden;
}

.progress {
  height: 100%;
  background-color: var(--color-primary);
  transition: width 0.3s ease;
}

.progress-text {
  font-weight: bold;
}

.timeline {
  position: relative;
  margin: 20px 0;
  padding-left: 30px;
}

.timeline:before {
  content: '';
  position: absolute;
  left: 10px;
  top: 0;
  height: 100%;
  width: 2px;
  background: var(--color-primary);
}

.timeline-event {
  position: relative;
  margin-bottom: 30px;
}

.timeline-event:before {
  content: '';
  position: absolute;
  left: -30px;
  top: 0;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: var(--color-primary);
}

.event-time {
  font-weight: bold;
  margin-bottom: 5px;
  color: var(--color-secondary);
}

.event-content {
  background: white;
  padding: 15px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.stats {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: 10px;
}

.stat-item {
  background: #f0f0f0;
  padding: 5px 10px;
  border-radius: 20px;
  font-size: 0.9em;
}

@media (max-width: 768px) {
  .simulation-container {
    flex-direction: column;
  }
}
</style> 