<template>
  <div class="theater">
    <h1>命运剧场</h1>
    
    <div class="theater-container">
      <div class="control-panel">
        <h3>剧场控制</h3>
        
        <div class="form-group">
          <label>选择场景</label>
          <select v-model="selectedScene">
            <option value="">请选择场景</option>
            <option v-for="scene in scenes" :key="scene.id" :value="scene.id">
              {{ scene.name }}
            </option>
          </select>
        </div>
        
        <div class="form-group">
          <label>选择主角</label>
          <select v-model="selectedCharacter">
            <option value="">请选择角色</option>
            <option v-for="char in characters" :key="char.id" :value="char.id">
              {{ char.name }}
            </option>
          </select>
        </div>
        
        <div class="form-group">
          <label>NPC数量</label>
          <input type="number" v-model.number="npcCount" min="0" max="5" />
        </div>
        
        <button class="btn primary" @click="startTheater" :disabled="!canStart">开始演出</button>
        
        <div class="scene-preview" v-if="selectedScene">
          <img :src="currentSceneImage" alt="场景预览" class="scene-preview-image" />
        </div>
      </div>
      
      <div class="theater-stage">
        <div v-if="!theaterStarted && !isLoading" class="empty-state">
          <p>选择场景与角色，开始命运演出</p>
        </div>
        
        <div v-if="isLoading" class="loading">
          <p>正在准备演出，请稍候...</p>
          <div class="loader"></div>
        </div>
        
        <div v-if="theaterStarted && !isLoading" class="stage">
          <div class="scene-description">
            <h3>{{ currentScene.name }}</h3>
            <div class="scene-image-container">
              <img :src="currentSceneImage" alt="场景图片" class="scene-image" />
            </div>
            <p>{{ currentScene.description }}</p>
          </div>
          
          <div class="dialogue-container">
            <div v-for="(dialogue, index) in dialogues" :key="index" 
                 class="dialogue-bubble" 
                 :class="{ 'character-dialogue': dialogue.character_id === selectedCharacter }">
              <div class="speaker">{{ dialogue.speaker }}</div>
              <div class="content">{{ dialogue.content }}</div>
            </div>
          </div>
          
          <div class="theatre-controls">
            <button class="btn" @click="addRandomDialogue">继续</button>
            <button class="btn secondary" @click="resetTheater">重置</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { apiService } from '../services/api'

const scenes = ref([])
const characters = ref([])
const selectedScene = ref('')
const selectedCharacter = ref('')
const npcCount = ref(2)
const isLoading = ref(false)
const theaterStarted = ref(false)
const currentScene = ref({})
const dialogues = ref([])

// 获取场景图片
const getSceneImage = (sceneId) => {
  const sceneImages = {
    1: '/images/scenes/cafe.svg',
    2: '/images/scenes/library.svg',
    3: '/images/scenes/mountain.svg',
    4: '/images/scenes/beach.svg'
  }
  return sceneImages[sceneId] || '/images/scenes/cafe.svg'
}

// 计算当前场景图片
const currentSceneImage = computed(() => {
  return getSceneImage(selectedScene.value)
})

// 计算属性 - 是否可以开始
const canStart = computed(() => {
  return selectedScene.value && selectedCharacter.value
})

// 载入数据
onMounted(async () => {
  await Promise.all([loadScenes(), loadCharacters()])
})

// 加载场景列表
const loadScenes = async () => {
  try {
    const data = await apiService.getScenes()
    scenes.value = data || []
  } catch (error) {
    console.error('获取场景列表失败:', error)
    // 模拟数据
    scenes.value = [
      { id: 1, name: '城市咖啡馆', description: '一个安静的咖啡馆，窗外是繁忙的城市街道。' },
      { id: 2, name: '古老图书馆', description: '尘封的书架间，时光仿佛静止。' },
      { id: 3, name: '山顶日落', description: '站在山顶，夕阳西下，整个城市尽收眼底。' },
      { id: 4, name: '海边小屋', description: '浪花拍打着岸边，木屋在微风中摇曳。' }
    ]
  }
}

// 加载角色列表
const loadCharacters = async () => {
  try {
    const data = await apiService.getCharacters()
    characters.value = data || []
  } catch (error) {
    console.error('获取角色列表失败:', error)
    // 模拟数据
    characters.value = [
      { id: 1, name: '张三' },
      { id: 2, name: '李四' },
      { id: 3, name: '王五' }
    ]
  }
}

// 开始剧场演出
const startTheater = async () => {
  isLoading.value = true
  dialogues.value = []
  
  try {
    // 获取场景详情
    const sceneData = await apiService.getScene(selectedScene.value)
    currentScene.value = sceneData
    
    // 开始演出
    const theaterData = await apiService.startTheater({
      scene_id: selectedScene.value,
      character_id: selectedCharacter.value,
      npc_count: npcCount.value
    })
    
    // 添加初始对话
    dialogues.value = theaterData.initial_dialogues || []
    
    theaterStarted.value = true
  } catch (error) {
    console.error('开始演出失败:', error)
    
    // 模拟数据
    const sceneIndex = scenes.value.findIndex(s => s.id == selectedScene.value)
    if (sceneIndex >= 0) {
      currentScene.value = scenes.value[sceneIndex]
    }
    
    const charIndex = characters.value.findIndex(c => c.id == selectedCharacter.value)
    const characterName = charIndex >= 0 ? characters.value[charIndex].name : '主角'
    
    // 模拟初始对话
    dialogues.value = [
      {
        speaker: '旁白',
        content: currentScene.value.description,
        character_id: null
      },
      {
        speaker: characterName,
        content: '这个地方真不错，让我好好看看周围。',
        character_id: selectedCharacter.value
      }
    ]
    
    theaterStarted.value = true
  } finally {
    isLoading.value = false
  }
}

// 添加随机对话
const addRandomDialogue = async () => {
  if (!theaterStarted.value) return
  
  try {
    const data = await apiService.nextTheaterDialog({
      scene_id: selectedScene.value,
      character_id: selectedCharacter.value
    })
    
    dialogues.value.push(data)
  } catch (error) {
    console.error('获取下一段对话失败:', error)
    
    // 模拟NPC名称
    const npcNames = ['服务员', '路人', '老板', '学者', '艺术家']
    const randomName = npcNames[Math.floor(Math.random() * npcNames.length)]
    
    // 模拟对话内容
    const dialogueContents = [
      '今天天气真不错，不是吗？',
      '你看起来面熟，我们之前见过吗？',
      '这个地方总是让我感到平静。',
      '你有什么特别的原因来这里吗？',
      '有时候命运的安排真是奇妙，不是吗？'
    ]
    const randomContent = dialogueContents[Math.floor(Math.random() * dialogueContents.length)]
    
    // 随机决定是NPC说话还是角色说话
    const isCharacterSpeaking = Math.random() > 0.6
    
    const charIndex = characters.value.findIndex(c => c.id == selectedCharacter.value)
    const characterName = charIndex >= 0 ? characters.value[charIndex].name : '主角'
    
    dialogues.value.push({
      speaker: isCharacterSpeaking ? characterName : randomName,
      content: randomContent,
      character_id: isCharacterSpeaking ? selectedCharacter.value : null
    })
  }
}

// 重置剧场
const resetTheater = () => {
  theaterStarted.value = false
  dialogues.value = []
  currentScene.value = {}
}
</script>

<style scoped>
.theater {
  padding: 20px;
}

h1 {
  margin-bottom: 30px;
  color: var(--color-primary);
}

.theater-container {
  display: flex;
  gap: 30px;
}

.control-panel {
  flex: 1;
  max-width: 300px;
  background: #f9f9f9;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.theater-stage {
  flex: 3;
  background: #f9f9f9;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  min-height: 500px;
  display: flex;
  flex-direction: column;
}

.form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 8px;
  font-weight: bold;
}

select, input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.btn {
  display: inline-block;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: bold;
  transition: background-color 0.3s;
}

.btn.primary {
  background-color: var(--color-primary);
  color: white;
}

.btn.secondary {
  background-color: #e0e0e0;
  color: #333;
}

.btn.primary:hover:not(:disabled) {
  background-color: #3aa876;
}

.btn.secondary:hover {
  background-color: #d0d0d0;
}

.btn:disabled {
  background-color: #cccccc;
  cursor: not-allowed;
}

.empty-state, .loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 400px;
  color: #666;
}

.loader {
  border: 5px solid #f3f3f3;
  border-top: 5px solid var(--color-primary);
  border-radius: 50%;
  width: 50px;
  height: 50px;
  animation: spin 2s linear infinite;
  margin-top: 20px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.stage {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.scene-description {
  background: #fff;
  padding: 15px;
  border-radius: 8px;
  margin-bottom: 20px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.scene-description h3 {
  color: var(--color-secondary);
  margin-bottom: 10px;
}

.dialogue-container {
  flex: 1;
  overflow-y: auto;
  padding: 10px;
  background: #fff;
  border-radius: 8px;
  margin-bottom: 20px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
  max-height: 300px;
}

.dialogue-bubble {
  margin-bottom: 15px;
  padding: 10px;
  border-radius: 8px;
  background: #f0f0f0;
  max-width: 80%;
}

.character-dialogue {
  background: #e1f5fe;
  margin-left: auto;
}

.speaker {
  font-weight: bold;
  margin-bottom: 5px;
  color: var(--color-secondary);
}

.theatre-controls {
  display: flex;
  gap: 10px;
  justify-content: center;
}

.scene-preview {
  margin-bottom: 20px;
}

.scene-preview-image {
  width: 100%;
  height: auto;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.scene-image-container {
  margin-bottom: 10px;
}

.scene-image {
  width: 100%;
  height: auto;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

@media (max-width: 768px) {
  .theater-container {
    flex-direction: column;
  }
  
  .control-panel {
    max-width: none;
  }
}
</style> 