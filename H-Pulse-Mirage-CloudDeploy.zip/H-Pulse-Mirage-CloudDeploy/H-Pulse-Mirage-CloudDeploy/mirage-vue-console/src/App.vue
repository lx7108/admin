<template>
  <div class="app-container">
    <header>
      <div class="logo">
        <img src="/logo.svg" alt="H-Pulse·Mirage Logo" class="logo-image">
      </div>
      <nav>
        <router-link to="/">首页</router-link>
        <router-link to="/simulation">命运模拟</router-link>
        <router-link to="/theater">命运剧场</router-link>
        <router-link to="/character">角色管理</router-link>
      </nav>
    </header>
    
    <main>
      <router-view />
    </main>
    
    <footer>
      <p>H-Pulse·Mirage © 2023</p>
    </footer>
  </div>
</template>

<style>
.app-container {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 20px;
}

header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 0;
  border-bottom: 1px solid #eee;
}

.logo {
  display: flex;
  align-items: center;
}

.logo-image {
  height: 40px;
  width: auto;
}

nav {
  display: flex;
  gap: 20px;
}

nav a {
  text-decoration: none;
  color: #2c3e50;
  font-weight: bold;
}

nav a.router-link-active {
  color: #42b983;
}

main {
  min-height: 70vh;
  padding: 20px 0;
}

footer {
  text-align: center;
  padding: 20px 0;
  border-top: 1px solid #eee;
  color: #666;
}
</style> 