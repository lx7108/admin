#!/bin/bash
# 完全重建后端容器

# 停止所有容器
echo "停止所有容器..."
docker compose down

# 备份原始Dockerfile
echo "备份原始Dockerfile..."
cp Dockerfile.backend Dockerfile.backend.bak

# 创建新的Dockerfile
echo "创建新的Dockerfile..."
cat > Dockerfile.backend.new << 'EOF'
FROM python:3.10-slim

WORKDIR /app

# 安装系统依赖
RUN apt-get update && apt-get install -y \
    build-essential \
    curl \
    netcat-openbsd \
    postgresql-client \
    && rm -rf /var/lib/apt/lists/*

# 复制项目文件
COPY mirage-backend-full/backend /app/backend
COPY mirage-backend-full/requirements.txt /app/

# 立即修复database.py文件
RUN sed -i 's/@event.listens_for(engine, "disconnect")/@event.listens_for(engine, "close")/g' /app/backend/app/database.py || true
RUN sed -i 's/def disconnect(dbapi_connection, connection_record):/def close_connection(dbapi_connection, connection_record):/g' /app/backend/app/database.py || true

# 创建启动脚本
RUN echo '#!/bin/bash\n\
set -e\n\
\n\
echo "等待数据库就绪..."\n\
COUNT=0\n\
MAX_RETRIES=60\n\
\n\
while ! pg_isready -h db -p 5432 -U mirage_user -d mirage_db; do\n\
  if [ $COUNT -eq $MAX_RETRIES ]; then\n\
    echo "数据库连接超时，退出..."\n\
    exit 1\n\
  fi\n\
  COUNT=$((COUNT+1))\n\
  echo "等待数据库启动... $COUNT/$MAX_RETRIES"\n\
  sleep 5\n\
done\n\
\n\
# 等待数据库完全就绪\n\
echo "数据库连接成功，等待10秒确保完全初始化..."\n\
sleep 10\n\
\n\
echo "尝试测试数据库连接..."\n\
PGPASSWORD=mirage_pass psql -h db -p 5432 -U mirage_user -d mirage_db -c "SELECT 1" || {\n\
  echo "数据库连接测试失败，请检查数据库配置..."\n\
  exit 1\n\
}\n\
\n\
# 确保没有错误的事件名称\n\
if grep -q "disconnect" /app/backend/app/database.py; then\n\
  echo "发现错误的事件名称，尝试最后修复..."\n\
  cat > /tmp/fix.py << "PYEOF"\n\
import re\n\
with open("/app/backend/app/database.py", "r") as f:\n\
    content = f.read()\n\
content = content.replace(\'@event.listens_for(engine, "disconnect")\', \'@event.listens_for(engine, "close")\')\n\
content = content.replace("def disconnect(dbapi_connection, connection_record):", "def close_connection(dbapi_connection, connection_record):")\n\
with open("/app/backend/app/database.py", "w") as f:\n\
    f.write(content)\n\
print("Database.py fixed!")\n\
PYEOF\n\
  python /tmp/fix.py\n\
fi\n\
\n\
# 显示最终的database.py文件\n\
echo "最终的database.py文件:"\n\
grep -A 2 -B 2 "listens_for" /app/backend/app/database.py\n\
\n\
echo "开始启动后端服务..."\n\
cd /app/backend\n\
exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --root-path /api\
' > /app/start.sh && chmod +x /app/start.sh

# 安装 Python 依赖
RUN pip install --no-cache-dir -r /app/requirements.txt

# 创建存储目录
RUN mkdir -p /app/storage

# 设置文件权限
RUN chmod -R 755 /app/backend
RUN chmod -R 777 /app/storage

# 设置环境变量
ENV PYTHONPATH=/app
ENV BACKEND_DIR=/app/backend

# 设置工作目录
WORKDIR /app/backend

# 启动命令
CMD ["/app/start.sh"]
EOF

# 替换Dockerfile
echo "替换Dockerfile..."
mv Dockerfile.backend.new Dockerfile.backend

# 修复database.py源文件
echo "修复database.py源文件..."
if [ -f "mirage-backend-full/backend/app/database.py" ]; then
  DB_PATH="mirage-backend-full/backend/app/database.py"
  if grep -q "@event.listens_for(engine, \"disconnect\")" "$DB_PATH"; then
    echo "发现源文件中有错误的事件名称，正在修复源文件..."
    # 创建备份
    cp "$DB_PATH" "${DB_PATH}.bak"
    # 修复文件
    sed -i 's/@event.listens_for(engine, "disconnect")/@event.listens_for(engine, "close")/g' "$DB_PATH"
    sed -i 's/def disconnect(/def close_connection(/g' "$DB_PATH"
    echo "源文件已修复"
  else
    echo "源文件中未发现错误的事件名称"
  fi
else
  echo "未找到源文件，跳过修复"
fi

# 清理Docker缓存彻底
echo "彻底清理Docker缓存..."
docker system prune -f
docker builder prune -f

# 构建镜像（使用--no-cache选项强制重新构建）
echo "重新构建镜像..."
docker compose build --no-cache backend

# 启动容器
echo "启动容器..."
docker compose up -d backend

# 等待容器启动
echo "等待容器启动..."
sleep 15

# 检查容器状态
echo "检查容器状态..."
docker ps -a | grep backend

# 查看容器日志
echo "查看容器日志..."
docker logs h-pulse-mirage-clouddeploy-backend-1

echo "完全修复流程完成" 