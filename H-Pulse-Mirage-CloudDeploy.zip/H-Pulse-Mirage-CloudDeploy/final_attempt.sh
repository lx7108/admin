#!/bin/bash
# 最终解决方案 - 解决SQLAlchemy事件错误

# 停止所有容器
echo "停止所有容器..."
docker compose down

# 创建一个完全新的数据库文件，而不是尝试修复现有的
echo "创建全新的database.py文件..."
cat > database.py.new << 'EOF'
from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.pool import QueuePool
from sqlalchemy.exc import SQLAlchemyError
from contextlib import contextmanager
import logging
import time
from app.config import settings

# 配置日志
logger = logging.getLogger(__name__)

# 数据库引擎配置
engine = create_engine(
    settings.DATABASE_URL,
    poolclass=QueuePool,
    pool_size=5,  # 减小连接池大小
    max_overflow=10,
    pool_timeout=60,  # 增加连接超时时间到60秒
    pool_recycle=1800,  # 30分钟回收连接
    pool_pre_ping=True,  # 每次连接前ping，确保连接有效
    echo=settings.DEBUG,  # 在DEBUG模式下打印SQL语句
    connect_args={
        "connect_timeout": 60,  # PostgreSQL连接超时时间
        "application_name": "h_pulse_mirage",  # 应用名称
        "keepalives": 1,  # 启用TCP keepalive
        "keepalives_idle": 60,  # 空闲60秒后发送keepalive
        "keepalives_interval": 10,  # keepalive间隔10秒
        "keepalives_count": 5  # 5次重试
    }
)

# 数据库连接事件监听
@event.listens_for(engine, "connect")
def connect(dbapi_connection, connection_record):
    logger.info("Database connection established")

@event.listens_for(engine, "checkout")
def checkout(dbapi_connection, connection_record, connection_proxy):
    logger.debug("Database connection checked out")

@event.listens_for(engine, "close")
def close_connection(dbapi_connection, connection_record):
    logger.info("Database connection closed")

# Session工厂
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# 基础模型类
class CustomBase:
    @declared_attr
    def __tablename__(cls):
        # 自动生成小写表名
        return cls.__name__.lower()

Base = declarative_base(cls=CustomBase)

# FastAPI依赖项函数
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# 上下文管理器，用于非依赖项的数据库会话需求
@contextmanager
def get_db_session():
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except SQLAlchemyError as e:
        session.rollback()
        logger.error(f"Database error: {str(e)}")
        raise
    finally:
        session.close()

# 测试数据库连接
def test_connection():
    max_retries = 5
    retry_delay = 5  # 秒
    
    for attempt in range(max_retries):
        try:
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))
                conn.commit()
            logger.info("Database connection test successful")
            return True
        except SQLAlchemyError as e:
            logger.error(f"Database connection test failed (attempt {attempt + 1}/{max_retries}): {str(e)}")
            if attempt < max_retries - 1:
                time.sleep(retry_delay)
            else:
                return False

# 初始化数据库表
def init_db():
    """初始化数据库"""
    try:
        Base.metadata.create_all(bind=engine)
        logger.info("Database tables created successfully")
    except SQLAlchemyError as e:
        logger.error(f"Failed to create database tables: {str(e)}")
        raise
EOF

# 检查原始源代码目录
DB_SOURCE_PATH="mirage-backend-full/backend/app/database.py"
if [ -f "$DB_SOURCE_PATH" ]; then
  echo "找到源码文件，备份并替换..."
  cp "$DB_SOURCE_PATH" "${DB_SOURCE_PATH}.bak.$(date +%s)"
  cp database.py.new "$DB_SOURCE_PATH"
  echo "源码文件已替换"
else
  echo "未找到源码文件，无法替换源码"
fi

# 创建新的Dockerfile，确保不使用缓存层
echo "创建新的Dockerfile..."
cat > Dockerfile.backend.new << 'EOF'
FROM python:3.10-slim

WORKDIR /app

# 安装系统依赖
RUN apt-get update && apt-get install -y \
    build-essential \
    curl \
    netcat-openbsd \
    postgresql-client \
    && rm -rf /var/lib/apt/lists/*

# 复制项目文件
COPY mirage-backend-full/backend /app/backend
COPY mirage-backend-full/requirements.txt /app/

# 确保database.py正确
COPY database.py.new /app/backend/app/database.py

# 创建启动脚本
RUN echo '#!/bin/bash\n\
set -e\n\
\n\
echo "等待数据库就绪..."\n\
COUNT=0\n\
MAX_RETRIES=60\n\
\n\
while ! pg_isready -h db -p 5432 -U mirage_user -d mirage_db; do\n\
  if [ $COUNT -eq $MAX_RETRIES ]; then\n\
    echo "数据库连接超时，退出..."\n\
    exit 1\n\
  fi\n\
  COUNT=$((COUNT+1))\n\
  echo "等待数据库启动... $COUNT/$MAX_RETRIES"\n\
  sleep 5\n\
done\n\
\n\
# 等待数据库完全就绪\n\
echo "数据库连接成功，等待10秒确保完全初始化..."\n\
sleep 10\n\
\n\
echo "尝试测试数据库连接..."\n\
PGPASSWORD=mirage_pass psql -h db -p 5432 -U mirage_user -d mirage_db -c "SELECT 1" || {\n\
  echo "数据库连接测试失败，请检查数据库配置..."\n\
  exit 1\n\
}\n\
\n\
# 显示最终的database.py事件监听器\n\
echo "最终的database.py文件中的事件监听器:"\n\
grep -A 2 -B 2 "listens_for" /app/backend/app/database.py || echo "未找到事件监听器"\n\
\n\
echo "开始启动后端服务..."\n\
cd /app/backend\n\
exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --root-path /api\
' > /app/start.sh && chmod +x /app/start.sh

# 安装 Python 依赖
RUN pip install --no-cache-dir -r /app/requirements.txt

# 创建存储目录
RUN mkdir -p /app/storage

# 设置文件权限
RUN chmod -R 755 /app/backend
RUN chmod -R 777 /app/storage

# 设置环境变量
ENV PYTHONPATH=/app
ENV BACKEND_DIR=/app/backend

# 设置工作目录
WORKDIR /app/backend

# 启动命令
CMD ["/app/start.sh"]
EOF

# 备份并替换Dockerfile
echo "备份并替换Dockerfile..."
cp Dockerfile.backend Dockerfile.backend.bak.$(date +%s)
mv Dockerfile.backend.new Dockerfile.backend

# 彻底清理Docker系统
echo "彻底清理Docker系统..."
docker system prune -a -f  # 清理所有未使用的对象
docker volume prune -f     # 清理未使用的卷
docker builder prune -a -f # 清理构建缓存

# 重新构建并启动容器
echo "重新构建并启动backend..."
docker compose build --no-cache backend
docker compose up -d backend

# 等待容器启动
echo "等待容器启动..."
sleep 20

# 检查容器状态和日志
echo "检查容器状态..."
docker ps -a | grep backend
echo "检查容器日志..."
docker logs h-pulse-mirage-clouddeploy-backend-1

# 清理临时文件
echo "清理临时文件..."
rm -f database.py.new

echo "最终修复尝试完成！" 