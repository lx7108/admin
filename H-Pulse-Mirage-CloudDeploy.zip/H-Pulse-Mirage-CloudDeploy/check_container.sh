#!/bin/bash

# 如果容器未运行，尝试启动一个
if ! docker ps | grep -q "h-pulse-mirage-clouddeploy-backend"; then
  echo "后端容器未运行，尝试启动..."
  docker compose up -d backend
  sleep 5
fi

# 获取容器ID
CONTAINER_ID=$(docker ps -a | grep "h-pulse-mirage-clouddeploy-backend" | awk '{print $1}')

if [ -z "$CONTAINER_ID" ]; then
  echo "无法找到后端容器ID，尝试以下另一种方法..."
  # 尝试使用compose容器名称
  CONTAINER_ID="h-pulse-mirage-clouddeploy-backend-1"
fi

echo "使用容器ID: $CONTAINER_ID"

# 检查容器中的文件
echo "检查容器中的database.py文件..."
docker exec $CONTAINER_ID cat /app/backend/app/database.py 2>/dev/null || echo "无法访问容器中的文件"

# 检查容器日志
echo "检查容器日志..."
docker logs $CONTAINER_ID | tail -n 50 || echo "无法获取容器日志"

# 检查容器中的Python版本和SQLAlchemy版本
echo "检查Python和SQLAlchemy版本..."
docker exec $CONTAINER_ID python -c "import sys; print(f'Python版本: {sys.version}')" 2>/dev/null || echo "无法获取Python版本"
docker exec $CONTAINER_ID python -c "import sqlalchemy; print(f'SQLAlchemy版本: {sqlalchemy.__version__}')" 2>/dev/null || echo "无法获取SQLAlchemy版本"

# 尝试修复：在容器内创建一个修复脚本
echo "尝试在容器内修复database.py文件..."
cat > fix_inside.py << 'EOF'
#!/usr/bin/env python3
import os
import re

def fix_file(file_path):
    """修复database.py文件中的事件监听器"""
    try:
        with open(file_path, 'r') as f:
            content = f.read()
        
        # 检查是否有错误的事件名
        if '@event.listens_for(engine, "disconnect")' in content:
            print(f"在文件 {file_path} 中发现错误的事件名")
            # 修复事件名
            content = content.replace(
                '@event.listens_for(engine, "disconnect")', 
                '@event.listens_for(engine, "close")'
            )
            content = content.replace(
                'def disconnect(dbapi_connection, connection_record):', 
                'def close_connection(dbapi_connection, connection_record):'
            )
            
            # 保存修复后的文件
            with open(file_path, 'w') as f:
                f.write(content)
            print(f"文件 {file_path} 已修复")
            return True
        else:
            print(f"文件 {file_path} 中未发现错误的事件名")
            return False
    except Exception as e:
        print(f"修复文件 {file_path} 时出错: {str(e)}")
        return False

# 主函数
if __name__ == "__main__":
    db_file = "/app/backend/app/database.py"
    if os.path.exists(db_file):
        fixed = fix_file(db_file)
        if fixed:
            print("修复成功!")
        else:
            print("文件已经是正确的或无法修复")
    else:
        print(f"文件 {db_file} 不存在")
EOF

# 将修复脚本复制到容器
echo "将修复脚本复制到容器..."
docker cp fix_inside.py $CONTAINER_ID:/tmp/fix_inside.py

# 在容器内执行修复脚本
echo "在容器内执行修复脚本..."
docker exec $CONTAINER_ID bash -c "python /tmp/fix_inside.py"

# 重启容器
echo "重启容器..."
docker restart $CONTAINER_ID

# 等待容器重启
echo "等待容器重启..."
sleep 5

# 检查容器状态
echo "检查容器状态..."
docker ps -a | grep backend

echo "检测和修复流程完成" 