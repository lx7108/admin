#!/bin/bash
# 为了直接修复容器中的文件

# 检查后端容器是否正在运行
CONTAINER_ID=$(docker ps -a | grep "h-pulse-mirage-clouddeploy-backend" | awk '{print $1}')

if [ -z "$CONTAINER_ID" ]; then
  echo "错误：找不到后端容器！"
  exit 1
fi

echo "找到后端容器 ID: $CONTAINER_ID"

# 创建临时修复脚本
cat > /tmp/fix_db.py << 'EOF'
#!/usr/bin/env python3

import os

def fix_database_file(file_path):
    print(f"尝试修复文件: {file_path}")
    if not os.path.exists(file_path):
        print(f"错误: 文件 {file_path} 不存在!")
        return False
    
    with open(file_path, 'r') as file:
        content = file.read()
    
    if '@event.listens_for(engine, "disconnect")' in content:
        print("找到错误的事件监听器，正在修复...")
        fixed_content = content.replace(
            '@event.listens_for(engine, "disconnect")',
            '@event.listens_for(engine, "close")'
        )
        fixed_content = fixed_content.replace(
            'def disconnect(dbapi_connection, connection_record):',
            'def close_connection(dbapi_connection, connection_record):'
        )
        
        with open(file_path, 'w') as file:
            file.write(fixed_content)
        
        print("文件修复完成!")
        return True
    else:
        print("文件内容正常，无需修复。")
        return False

# 主要的数据库文件
db_file = "/app/backend/app/database.py"
fix_database_file(db_file)
EOF

# 将修复脚本复制到容器
echo "复制修复脚本到容器..."
docker cp /tmp/fix_db.py $CONTAINER_ID:/tmp/fix_db.py

# 在容器中执行修复脚本
echo "在容器中执行修复脚本..."
docker exec $CONTAINER_ID bash -c "chmod +x /tmp/fix_db.py && python /tmp/fix_db.py"

# 重新启动容器
echo "重新启动容器..."
docker restart $CONTAINER_ID

# 等待容器启动
echo "等待容器启动..."
sleep 5

# 检查容器状态
echo "检查容器状态..."
docker ps -a | grep backend

# 删除临时脚本
rm -f /tmp/fix_db.py

echo "修复流程结束！" 