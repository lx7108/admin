# 部署配置
$SERVER_IP = "8.148.68.190"
$SERVER_USER = "root"
$DEPLOY_DIR = "H-Pulse-Mirage-CloudDeploy"
$LOCAL_ZIP = "$DEPLOY_DIR.zip"

Write-Host "🚀 开始一键部署 H-Pulse·Mirage 到云服务器 $SERVER_IP..." -ForegroundColor Cyan

# 创建部署目录
Write-Host "📂 创建临时部署目录..." -ForegroundColor Yellow
New-Item -ItemType Directory -Path $DEPLOY_DIR -Force | Out-Null

# 复制必要文件
Write-Host "📋 复制项目文件..." -ForegroundColor Yellow
Copy-Item -Path "mirage-vue-console" -Destination "$DEPLOY_DIR/" -Recurse -Force
Copy-Item -Path "mirage-backend-full" -Destination "$DEPLOY_DIR/" -Recurse -Force
Copy-Item -Path "docker-compose.yml" -Destination "$DEPLOY_DIR/" -Force
Copy-Item -Path "Dockerfile.frontend" -Destination "$DEPLOY_DIR/" -Force
Copy-Item -Path "Dockerfile.backend" -Destination "$DEPLOY_DIR/" -Force
Copy-Item -Path "init_postgres.sql" -Destination "$DEPLOY_DIR/" -Force
Copy-Item -Path "init_server.sh" -Destination "$DEPLOY_DIR/" -Force
Copy-Item -Path "nginx.conf" -Destination "$DEPLOY_DIR/" -Force

# 复制Docker镜像加速器脚本
Copy-Item -Path "setup_docker_mirror.sh" -Destination "$DEPLOY_DIR/" -Force

# 打包文件
Write-Host "📦 打包项目文件..." -ForegroundColor Yellow
if (Test-Path $LOCAL_ZIP) {
    Remove-Item $LOCAL_ZIP -Force
}
Compress-Archive -Path $DEPLOY_DIR -DestinationPath $LOCAL_ZIP

# 询问用户是否有SSH密钥
$hasKey = Read-Host "您是否已经设置SSH密钥认证？(y/n)"

if ($hasKey -eq 'y' -or $hasKey -eq 'Y') {
    # 使用SSH自动上传和执行
    Write-Host "📤 上传文件到服务器..." -ForegroundColor Yellow
    
    # 检查是否安装了OpenSSH
    $hasOpenSSH = Get-Command ssh -ErrorAction SilentlyContinue
    
    if ($hasOpenSSH) {
        # 使用内置OpenSSH
        Write-Host "🔑 使用OpenSSH上传和执行..." -ForegroundColor Yellow
        
        # 上传文件
        scp $LOCAL_ZIP $SERVER_USER@$SERVER_IP:~/$LOCAL_ZIP
        
        # 执行远程命令
        ssh $SERVER_USER@$SERVER_IP "unzip -o ~/$LOCAL_ZIP -d ~/ && cd ~/$DEPLOY_DIR && bash setup_docker_mirror.sh && bash init_server.sh"
    } else {
        # 使用PSCP (需要PuTTY工具包)
        $pscpPath = Read-Host "请输入PSCP.exe的完整路径 (如: C:\path\to\pscp.exe)"
        
        if (Test-Path $pscpPath) {
            Write-Host "🔑 使用PSCP上传文件..." -ForegroundColor Yellow
            & $pscpPath $LOCAL_ZIP $SERVER_USER@$SERVER_IP:~/$LOCAL_ZIP
            
            # 使用Plink执行远程命令
            $plinkPath = $pscpPath -replace "pscp.exe", "plink.exe"
            
            if (Test-Path $plinkPath) {
                Write-Host "🔧 使用Plink执行远程命令..." -ForegroundColor Yellow
                & $plinkPath -batch $SERVER_USER@$SERVER_IP "unzip -o ~/$LOCAL_ZIP -d ~/ && cd ~/$DEPLOY_DIR && bash setup_docker_mirror.sh && bash init_server.sh"
            } else {
                Write-Host "⚠️ 未找到Plink工具，请手动执行以下命令:" -ForegroundColor Red
                Write-Host "   1. 登录服务器: ssh $SERVER_USER@$SERVER_IP" -ForegroundColor Yellow
                Write-Host "   2. 解压文件: unzip -o ~/$LOCAL_ZIP -d ~/" -ForegroundColor Yellow
                Write-Host "   3. 进入目录: cd ~/$DEPLOY_DIR" -ForegroundColor Yellow
                Write-Host "   4. 配置Docker: bash setup_docker_mirror.sh" -ForegroundColor Yellow
                Write-Host "   5. 执行部署: bash init_server.sh" -ForegroundColor Yellow
            }
        } else {
            Write-Host "⚠️ PSCP路径无效，请手动上传和执行:" -ForegroundColor Red
            Write-Host "   1. 手动上传 $LOCAL_ZIP 到服务器" -ForegroundColor Yellow
            Write-Host "   2. 登录服务器: ssh $SERVER_USER@$SERVER_IP" -ForegroundColor Yellow
            Write-Host "   3. 解压文件: unzip -o ~/$LOCAL_ZIP -d ~/" -ForegroundColor Yellow
            Write-Host "   4. 进入目录: cd ~/$DEPLOY_DIR" -ForegroundColor Yellow
            Write-Host "   5. 配置Docker: bash setup_docker_mirror.sh" -ForegroundColor Yellow
            Write-Host "   6. 执行部署: bash init_server.sh" -ForegroundColor Yellow
        }
    }
} else {
    # 提供手动操作指南
    Write-Host "⚠️ 请手动完成以下步骤:" -ForegroundColor Red
    Write-Host "   1. 手动上传 $LOCAL_ZIP 到服务器" -ForegroundColor Yellow
    Write-Host "   2. 登录服务器: ssh $SERVER_USER@$SERVER_IP" -ForegroundColor Yellow
    Write-Host "   3. 解压文件: unzip -o ~/$LOCAL_ZIP -d ~/" -ForegroundColor Yellow
    Write-Host "   4. 进入目录: cd ~/$DEPLOY_DIR" -ForegroundColor Yellow
    Write-Host "   5. 配置Docker: bash setup_docker_mirror.sh" -ForegroundColor Yellow
    Write-Host "   6. 执行部署: bash init_server.sh" -ForegroundColor Yellow
}

# 清理本地文件
Write-Host "🧹 是否清理本地临时文件？(y/n)" -ForegroundColor Yellow
$cleanUp = Read-Host

if ($cleanUp -eq 'y' -or $cleanUp -eq 'Y') {
    Write-Host "🧹 清理本地临时文件..." -ForegroundColor Yellow
    Remove-Item -Path $DEPLOY_DIR -Recurse -Force
    # 保留zip文件，以便需要时可以再次使用
}

Write-Host "✅ 部署流程执行完毕！" -ForegroundColor Green
Write-Host "🌐 前端访问地址: http://$SERVER_IP:80" -ForegroundColor Cyan
Write-Host "🌐 后端API地址: http://$SERVER_IP:8000/api" -ForegroundColor Cyan 