#!/bin/bash
# 修复SQLAlchemy事件问题的最终解决方案

set -e # 遇到错误立即退出
set -x # 打印执行的命令

echo "========== 开始修复 =========="

# 停止所有容器
echo "停止所有容器..."
docker compose down

# 创建新的正确版database.py
echo "创建正确版本的database.py..."
cat > database.py.new << 'EOF'
from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.pool import QueuePool
from sqlalchemy.exc import SQLAlchemyError
from contextlib import contextmanager
import logging
import time
from app.config import settings

# 配置日志
logger = logging.getLogger(__name__)

# 数据库引擎配置
engine = create_engine(
    settings.DATABASE_URL,
    poolclass=QueuePool,
    pool_size=5,  # 减小连接池大小
    max_overflow=10,
    pool_timeout=60,  # 增加连接超时时间到60秒
    pool_recycle=1800,  # 30分钟回收连接
    pool_pre_ping=True,  # 每次连接前ping，确保连接有效
    echo=settings.DEBUG,  # 在DEBUG模式下打印SQL语句
    connect_args={
        "connect_timeout": 60,  # PostgreSQL连接超时时间
        "application_name": "h_pulse_mirage",  # 应用名称
        "keepalives": 1,  # 启用TCP keepalive
        "keepalives_idle": 60,  # 空闲60秒后发送keepalive
        "keepalives_interval": 10,  # keepalive间隔10秒
        "keepalives_count": 5  # 5次重试
    }
)

# 数据库连接事件监听
@event.listens_for(engine, "connect")
def connect(dbapi_connection, connection_record):
    logger.info("Database connection established")

@event.listens_for(engine, "checkout")
def checkout(dbapi_connection, connection_record, connection_proxy):
    logger.debug("Database connection checked out")

@event.listens_for(engine, "close")
def close_connection(dbapi_connection, connection_record):
    logger.info("Database connection closed")

# Session工厂
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# 基础模型类
class CustomBase:
    @declared_attr
    def __tablename__(cls):
        # 自动生成小写表名
        return cls.__name__.lower()

Base = declarative_base(cls=CustomBase)

# FastAPI依赖项函数
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# 上下文管理器，用于非依赖项的数据库会话需求
@contextmanager
def get_db_session():
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except SQLAlchemyError as e:
        session.rollback()
        logger.error(f"Database error: {str(e)}")
        raise
    finally:
        session.close()

# 测试数据库连接
def test_connection():
    max_retries = 5
    retry_delay = 5  # 秒
    
    for attempt in range(max_retries):
        try:
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))
                conn.commit()
            logger.info("Database connection test successful")
            return True
        except SQLAlchemyError as e:
            logger.error(f"Database connection test failed (attempt {attempt + 1}/{max_retries}): {str(e)}")
            if attempt < max_retries - 1:
                time.sleep(retry_delay)
            else:
                return False

# 初始化数据库表
def init_db():
    """初始化数据库"""
    try:
        Base.metadata.create_all(bind=engine)
        logger.info("Database tables created successfully")
    except SQLAlchemyError as e:
        logger.error(f"Failed to create database tables: {str(e)}")
        raise
EOF

# 1. 替换源代码文件
DB_SOURCE_PATH="mirage-backend-full/backend/app/database.py"
if [ -f "$DB_SOURCE_PATH" ]; then
    echo "发现源代码文件，备份并替换..."
    cp "$DB_SOURCE_PATH" "${DB_SOURCE_PATH}.bak.$(date +%s)"
    cp database.py.new "$DB_SOURCE_PATH"
    echo "源代码文件已替换"
else 
    echo "警告：未找到源代码文件 $DB_SOURCE_PATH"
    mkdir -p $(dirname "$DB_SOURCE_PATH")
    cp database.py.new "$DB_SOURCE_PATH"
    echo "已创建新的源代码文件"
fi

# 创建修复的requirements.txt
echo "创建修复的requirements.txt..."
cat > requirements.txt.fixed << 'EOF'
alembic==1.12.0
fastapi==0.109.0
python-jose==3.3.0
passlib==1.7.4
pydantic==2.4.2
pydantic-settings==2.0.3
pytest==7.4.2
sqlalchemy==2.0.21
prometheus-client==0.17.1
psutil==5.9.5
numpy==1.26.0
requests==2.31.0
uvicorn==0.23.2
python-dotenv==1.0.0
psycopg2-binary==2.9.7
EOF

# 替换requirements.txt
REQUIREMENTS_PATH="mirage-backend-full/requirements.txt"
if [ -f "$REQUIREMENTS_PATH" ]; then
    echo "备份并替换requirements.txt..."
    cp "$REQUIREMENTS_PATH" "${REQUIREMENTS_PATH}.bak"
    cp requirements.txt.fixed "$REQUIREMENTS_PATH"
fi

# 2. 修改Dockerfile.backend，确保database.py正确
echo "更新Dockerfile.backend..."
cat > Dockerfile.backend.new << 'EOF'
FROM python:3.10-slim

WORKDIR /app

# 安装系统依赖
RUN apt-get update && apt-get install -y \
    build-essential \
    curl \
    netcat-openbsd \
    postgresql-client \
    && rm -rf /var/lib/apt/lists/*

# 复制项目文件
COPY mirage-backend-full/backend /app/backend
COPY mirage-backend-full/requirements.txt /app/

# 复制修复后的数据库文件到容器中
COPY database.py.new /app/backend/app/database.py

# 创建启动脚本
RUN echo '#!/bin/bash\n\
set -e\n\
\n\
echo "等待数据库就绪..."\n\
COUNT=0\n\
MAX_RETRIES=60\n\
\n\
while ! pg_isready -h db -p 5432 -U mirage_user -d mirage_db; do\n\
  if [ $COUNT -eq $MAX_RETRIES ]; then\n\
    echo "数据库连接超时，退出..."\n\
    exit 1\n\
  fi\n\
  COUNT=$((COUNT+1))\n\
  echo "等待数据库启动... $COUNT/$MAX_RETRIES"\n\
  sleep 5\n\
done\n\
\n\
# 等待数据库完全就绪\n\
echo "数据库连接成功，等待10秒确保完全初始化..."\n\
sleep 10\n\
\n\
echo "尝试测试数据库连接..."\n\
PGPASSWORD=mirage_pass psql -h db -p 5432 -U mirage_user -d mirage_db -c "SELECT 1" || {\n\
  echo "数据库连接测试失败，请检查数据库配置..."\n\
  exit 1\n\
}\n\
\n\
# 确认database.py没有错误的事件名\n\
if grep -q "disconnect" /app/backend/app/database.py; then\n\
  echo "错误：database.py仍有错误的事件名称，尝试修复..."\n\
  sed -i "s/@event.listens_for(engine, \\"disconnect\\")/@event.listens_for(engine, \\"close\\")/g" /app/backend/app/database.py\n\
  sed -i "s/def disconnect(/def close_connection(/g" /app/backend/app/database.py\n\
  \n\
  if grep -q "disconnect" /app/backend/app/database.py; then\n\
    echo "修复失败，手动替换整个文件..."\n\
    cat > /app/backend/app/database.py << "DBEOF"\n\
from sqlalchemy import create_engine, event, text\n\
from sqlalchemy.orm import sessionmaker, declarative_base\n\
from sqlalchemy.ext.declarative import declared_attr\n\
from sqlalchemy.pool import QueuePool\n\
from sqlalchemy.exc import SQLAlchemyError\n\
from contextlib import contextmanager\n\
import logging\n\
import time\n\
from app.config import settings\n\
\n\
# 配置日志\n\
logger = logging.getLogger(__name__)\n\
\n\
# 数据库引擎配置\n\
engine = create_engine(\n\
    settings.DATABASE_URL,\n\
    poolclass=QueuePool,\n\
    pool_size=5,\n\
    max_overflow=10,\n\
    pool_timeout=60,\n\
    pool_recycle=1800,\n\
    pool_pre_ping=True,\n\
    echo=settings.DEBUG,\n\
    connect_args={\n\
        "connect_timeout": 60,\n\
        "application_name": "h_pulse_mirage",\n\
        "keepalives": 1,\n\
        "keepalives_idle": 60,\n\
        "keepalives_interval": 10,\n\
        "keepalives_count": 5\n\
    }\n\
)\n\
\n\
# 数据库连接事件监听\n\
@event.listens_for(engine, "connect")\n\
def connect(dbapi_connection, connection_record):\n\
    logger.info("Database connection established")\n\
\n\
@event.listens_for(engine, "checkout")\n\
def checkout(dbapi_connection, connection_record, connection_proxy):\n\
    logger.debug("Database connection checked out")\n\
\n\
@event.listens_for(engine, "close")\n\
def close_connection(dbapi_connection, connection_record):\n\
    logger.info("Database connection closed")\n\
\n\
# Session工厂\n\
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)\n\
\n\
# 基础模型类\n\
class CustomBase:\n\
    @declared_attr\n\
    def __tablename__(cls):\n\
        return cls.__name__.lower()\n\
\n\
Base = declarative_base(cls=CustomBase)\n\
\n\
# FastAPI依赖项函数\n\
def get_db():\n\
    db = SessionLocal()\n\
    try:\n\
        yield db\n\
    finally:\n\
        db.close()\n\
\n\
# 上下文管理器\n\
@contextmanager\n\
def get_db_session():\n\
    session = SessionLocal()\n\
    try:\n\
        yield session\n\
        session.commit()\n\
    except SQLAlchemyError as e:\n\
        session.rollback()\n\
        logger.error(f"Database error: {str(e)}")\n\
        raise\n\
    finally:\n\
        session.close()\n\
\n\
# 测试数据库连接\n\
def test_connection():\n\
    max_retries = 5\n\
    retry_delay = 5\n\
    \n\
    for attempt in range(max_retries):\n\
        try:\n\
            with engine.connect() as conn:\n\
                conn.execute(text("SELECT 1"))\n\
                conn.commit()\n\
            logger.info("Database connection test successful")\n\
            return True\n\
        except SQLAlchemyError as e:\n\
            logger.error(f"Database connection test failed (attempt {attempt + 1}/{max_retries}): {str(e)}")\n\
            if attempt < max_retries - 1:\n\
                time.sleep(retry_delay)\n\
            else:\n\
                return False\n\
\n\
# 初始化数据库表\n\
def init_db():\n\
    try:\n\
        Base.metadata.create_all(bind=engine)\n\
        logger.info("Database tables created successfully")\n\
    except SQLAlchemyError as e:\n\
        logger.error(f"Failed to create database tables: {str(e)}")\n\
        raise\n\
DBEOF\n\
  fi\n\
fi\n\
\n\
echo "开始启动后端服务..."\n\
cd /app/backend\n\
exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --root-path /api\
' > /app/start.sh && chmod +x /app/start.sh

# 安装 Python 依赖
# 修改pip安装命令，使其更健壮并分开安装可能有问题的包
RUN pip install --upgrade pip && \
    pip install --no-cache-dir -v psycopg2-binary && \
    pip install --no-cache-dir -v sqlalchemy==2.0.21 && \
    grep -v "torch\|gym" /app/requirements.txt > /app/requirements_base.txt && \
    pip install --no-cache-dir -v -r /app/requirements_base.txt

# 创建存储目录
RUN mkdir -p /app/storage

# 设置文件权限
RUN chmod -R 755 /app/backend
RUN chmod -R 777 /app/storage

# 设置环境变量
ENV PYTHONPATH=/app
ENV BACKEND_DIR=/app/backend

# 设置工作目录
WORKDIR /app/backend

# 启动命令
CMD ["/app/start.sh"]
EOF

# 备份并替换Dockerfile
cp Dockerfile.backend Dockerfile.backend.bak.$(date +%s)
mv Dockerfile.backend.new Dockerfile.backend

# 3. 彻底清理Docker缓存
echo "彻底清理Docker缓存..."
docker system prune -a -f
docker builder prune -a -f
docker volume prune -f

# 4. 重新构建和启动
echo "重新构建镜像..."
docker compose build --no-cache backend

echo "启动容器..."
docker compose up -d backend

# 等待容器启动
echo "等待容器启动..."
sleep 20

# 检查容器状态
echo "检查容器状态..."
docker ps -a | grep backend
docker logs h-pulse-mirage-clouddeploy-backend-1

echo "========== 修复完成 ==========" 