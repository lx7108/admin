import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/simulation',
      name: 'simulation',
      component: () => import('../views/SimulationView.vue')
    },
    {
      path: '/theater',
      name: 'theater',
      component: () => import('../views/TheaterView.vue')
    },
    {
      path: '/character',
      name: 'character',
      component: () => import('../views/CharacterView.vue')
    }
  ]
})

export default router 